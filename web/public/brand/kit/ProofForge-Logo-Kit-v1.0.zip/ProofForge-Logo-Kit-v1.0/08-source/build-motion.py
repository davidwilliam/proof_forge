#!/usr/bin/env python3
"""Build 09-motion: the splash animation as one standalone HTML file (inline SVG and CSS
keyframes, no scripts, no fonts: every shape and label is outlined), then render it.

Frames are captured deterministically by headless Chrome (08-source/browser.mjs pauses every
animation and seeks it frame by frame), and ffmpeg encodes MP4 and GIF at 1920 x 1080 and
1080 x 1080. Run after build-kit.py and build-docs.py. Needs Node 22 or later, Chrome or
chrome-headless-shell, ffmpeg and rsvg-convert. Writes manifest-sha256.json last.
"""
from __future__ import annotations
import base64, importlib.util, json, shutil, subprocess, tempfile
from pathlib import Path
from PIL import Image

SRC = Path(__file__).resolve().parent


def load(name: str, file: str):
    spec = importlib.util.spec_from_file_location(name, SRC / file)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


K = load('build_kit', 'build-kit.py')
D = load('build_docs', 'build-docs.py')
KIT = SRC.parent
OUT = KIT / '09-motion'
C = K.C
F = K.fmt
FPS = 30
DURATION_MS = 5600  # the sequence ends at 4.55 s; the lockup holds for the rest
FORMATS = [(1920, 1080), (1080, 1080)]
KEYFRAMES = [0.6, 1.1, 1.7, 2.5, 3.2, 3.8, 4.2, 5.0]

# Sequence, in seconds: (delay, duration).
T = {
    'p1': (0.25, 0.50), 'p2': (0.55, 0.50), 'l1': (0.45, 0.40),
    'line': (1.20, 0.65), 'l2': (1.40, 0.40),
    'block': (2.05, 0.60), 'glow': (2.30, 1.20), 'l3': (2.30, 0.40),
    'labelsOut': (3.00, 0.35),
    'slide': (3.50, 0.95), 'word': (3.58, 0.90),
}
LABEL_SIZE = 12.0  # units of the lockup artboard (font size 100)


def splash_html() -> str:
    g = K.lockup_geometry()['horizontal']
    W, H = g['width'], g['height']
    dx, dy = g['offset']
    m = g['markInk']
    k = (m[3] - m[1]) / K.INK_H
    ox, oy = m[0] + dx - K.INK[0] * k, m[1] + dy - K.INK[1] * k
    shift = W / 2 - (m[0] + dx + (m[2] - m[0]) / 2)  # moves the mark to the artboard centre

    def part(rect, cls, fill, extra=''):
        return f'<path class="{cls}" fill="{fill}"{extra} d="{K.rrect(*K.place(rect, k, ox, oy))}"/>'

    mark = (part(K.BLOCK, 'glow', C['forge'], ' filter="url(#soft)"') +
            part(K.PREMISE_L, 'part p1', C['frost']) + part(K.PREMISE_R, 'part p2', C['frost']) +
            part(K.LINE, 'part line', C['frost']) + part(K.BLOCK, 'part block', C['forge']))
    word = K.wordmark_at(C['frost'], g['wordOriginX'] + dx, dy)
    lx = m[2] + dx + shift + 14
    labels = []
    for cls, gy, text, lead in [('l1', 28, 'premises', C['ion']), ('l2', 46.5, 'inference line', C['ion']),
                                ('l3', 71, 'conclusion: proved', C['forge'])]:
        y = oy + gy * k
        labels.append(f'<g class="lab {cls}"><path d="M{F(lx)} {F(y)}H{F(lx + 12)}" stroke="{lead}" stroke-width="0.9"/>'
                      + K.text_path(text, 'mono-500', LABEL_SIZE, lx + 18, y + LABEL_SIZE * 0.36, C['mist']) + '</g>')

    def anim(name, key, ease):
        d, t = T[key]
        return f'animation:{name} {t}s {ease} {d}s both'

    out = 'cubic-bezier(.2,.7,.2,1)'
    css = f'''
html,body{{margin:0;height:100%}}
body{{background-color:{C["void"]};background-image:radial-gradient({C["steel"]} 1px,transparent 1.2px);background-size:28px 28px;background-position:14px 14px;display:grid;place-items:center;overflow:hidden}}
svg{{width:min(80vw,1240px,112vh);height:auto;overflow:visible;display:block}}
.part,.glow{{transform-box:fill-box;transform-origin:center}}
.glow{{opacity:0}}
.labels{{opacity:0}}
.p1{{{anim('pf-drop', 'p1', out)}}}
.p2{{{anim('pf-drop', 'p2', out)}}}
.line{{{anim('pf-draw', 'line', out)}}}
.block{{{anim('pf-land', 'block', 'cubic-bezier(.2,.8,.25,1.25)')}}}
.glow{{{anim('pf-glow', 'glow', 'ease-out')}}}
.l1{{{anim('pf-label', 'l1', 'ease-out')}}}
.l2{{{anim('pf-label', 'l2', 'ease-out')}}}
.l3{{{anim('pf-label', 'l3', 'ease-out')}}}
.labels{{{anim('pf-out', 'labelsOut', 'ease-in')}}}
.mark{{{anim('pf-slide', 'slide', 'cubic-bezier(.65,0,.25,1)')}}}
.word{{{anim('pf-slide', 'slide', 'cubic-bezier(.65,0,.25,1)')}, {anim('pf-wipe', 'word', 'cubic-bezier(.45,0,.25,1)').split(':', 1)[1]}}}
@keyframes pf-drop{{from{{opacity:0;transform:translateY(-14px)}}to{{opacity:1;transform:none}}}}
@keyframes pf-draw{{from{{transform:scaleX(0)}}to{{transform:scaleX(1)}}}}
@keyframes pf-land{{from{{opacity:0;transform:translateY(-18px) scale(.55)}}to{{opacity:1;transform:none}}}}
@keyframes pf-glow{{0%{{opacity:0;transform:scale(1)}}30%{{opacity:.6}}100%{{opacity:0;transform:scale(2.3)}}}}
@keyframes pf-label{{from{{opacity:0;transform:translateX(-6px)}}to{{opacity:1;transform:none}}}}
@keyframes pf-out{{from{{opacity:1}}to{{opacity:0}}}}
@keyframes pf-slide{{from{{transform:translateX({F(shift)}px)}}to{{transform:none}}}}
@keyframes pf-wipe{{from{{clip-path:inset(-10% 100% -10% 0)}}to{{clip-path:inset(-10% 0 -10% 0)}}}}
@media (prefers-reduced-motion: reduce){{.part,.glow,.lab,.labels,.mark,.word{{animation:none}}}}
'''
    return (f'<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
            f'<meta name="viewport" content="width=device-width,initial-scale=1">\n<title>ProofForge splash</title>\n'
            f'<!-- ProofForge splash v1.0. The premises drop in, the inference line draws from the centre, the conclusion lands;\n'
            f'     the mark then slides left while the wordmark wipes in at its final gap. Reduced motion shows the final lockup at once. -->\n'
            f'<style>{css}</style>\n</head>\n<body>\n'
            f'<svg viewBox="0 0 {F(W)} {F(H)}" role="img" aria-label="ProofForge">'
            f'<defs><filter id="soft" x="-1" y="-1" width="3" height="3"><feGaussianBlur stdDeviation="3"/></filter></defs>'
            f'<g class="word">{word}</g><g class="mark">{mark}</g><g class="labels" aria-hidden="true">{"".join(labels)}</g></svg>\n'
            f'</body>\n</html>\n')


def ffmpeg(*args: str) -> None:
    subprocess.run(['ffmpeg', '-v', 'error', '-y', *args], check=True)


def contact_sheet(frames_dir: Path, out: Path) -> None:
    cols, tw = 4, 460
    th = round(tw * 1080 / 1920)
    gap, top = 20, 30
    rows = (len(KEYFRAMES) + cols - 1) // cols
    W = cols * tw + (cols + 1) * gap
    H = rows * (th + top + 18) + gap
    parts = [f'<rect width="{W}" height="{H}" fill="{C["graphite"]}"/>']
    for i, t in enumerate(KEYFRAMES):
        x = gap + (i % cols) * (tw + gap)
        y = gap + (i // cols) * (th + top + 18)
        n = round(t * FPS)
        im = Image.open(frames_dir / f'frame-{n:05d}.png').convert('RGB').resize((tw, th), Image.LANCZOS)
        buf = Path(tempfile.mkstemp(suffix='.png')[1])
        im.save(buf)
        data = base64.b64encode(buf.read_bytes()).decode()
        buf.unlink()
        parts.append(K.text_path(f'{t:.1f} s', 'mono-400', 14, x, y + 16, C['mist']))
        parts.append(f'<image x="{x}" y="{y + top}" width="{tw}" height="{th}" href="data:image/png;base64,{data}"/>')
    D.render(D.sheet(W, H, ''.join(parts), 'ProofForge splash key frames'), out, W)


def ink_centroid(path: Path) -> tuple[float, float, float]:
    im = Image.open(path).convert('L')
    w, h = im.size
    px = im.load()
    sx = sy = mass = 0.0
    for y in range(h):
        for x in range(w):
            v = px[x, y] - 40  # above the Void ground and the dot grid
            if v > 0:
                sx += v * x
                sy += v * y
                mass += v
    return sx / mass, sy / mass, mass


def build() -> dict:
    shutil.rmtree(OUT, ignore_errors=True)
    OUT.mkdir()
    html = OUT / 'proofforge-splash.html'
    html.write_text(splash_html())
    report = {}
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        tasks = []
        for w, h in FORMATS:
            tasks.append({'type': 'frames', 'url': html.as_uri(), 'width': w, 'height': h, 'fps': FPS,
                          'durationMs': DURATION_MS, 'outdir': str(tmp / f'{w}x{h}')})
            tasks.append({'type': 'shot', 'url': html.as_uri(), 'width': w, 'height': h, 'reducedMotion': True,
                          'out': str(tmp / f'reduced-{w}x{h}.png')})
        D.browser(tasks)
        for w, h in FORMATS:
            frames = tmp / f'{w}x{h}'
            last = sorted(frames.glob('frame-*.png'))[-1]
            shutil.copy(last, OUT / f'proofforge-splash-poster-{w}x{h}.png')
            ffmpeg('-framerate', str(FPS), '-i', str(frames / 'frame-%05d.png'),
                   '-vf', 'scale=out_color_matrix=bt709:out_range=tv,format=yuv420p',
                   '-c:v', 'libx264', '-preset', 'slow', '-crf', '16', '-tune', 'animation',
                   '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-color_range', 'tv',
                   '-movflags', '+faststart', str(OUT / f'proofforge-splash-{w}x{h}.mp4'))
            gw = w // 2
            ffmpeg('-framerate', str(FPS), '-i', str(frames / 'frame-%05d.png'), '-vf',
                   f'fps=20,scale={gw}:-1:flags=lanczos,split[a][b];[a]palettegen=max_colors=96:stats_mode=full[p];'
                   '[b][p]paletteuse=dither=sierra2_4a', '-loop', '0', str(OUT / f'proofforge-splash-{gw}x{gw * h // w}.gif'))
            # Reduced motion must show the final lockup: compare the ink centroid and mass of the two renders
            # (pixel values differ slightly at edges because animated layers are composited separately).
            ca, cb = ink_centroid(tmp / f'reduced-{w}x{h}.png'), ink_centroid(last)
            report[f'{w}x{h}'] = {'frames': len(list(frames.glob('frame-*.png'))),
                                  'reducedMotionCentroidOffsetPx': round(max(abs(ca[0] - cb[0]), abs(ca[1] - cb[1])), 3),
                                  'reducedMotionInkMassRatio': round(ca[2] / cb[2], 4)}
            assert report[f'{w}x{h}']['reducedMotionCentroidOffsetPx'] < 0.25, report
            if (w, h) == FORMATS[0]:
                contact_sheet(frames, OUT / 'proofforge-splash-frames.png')
    return report


if __name__ == '__main__':
    r = build()
    print(json.dumps(r, indent=1))
    K.manifest()
