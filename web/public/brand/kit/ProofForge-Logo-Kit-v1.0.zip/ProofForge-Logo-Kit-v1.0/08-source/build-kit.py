#!/usr/bin/env python3
"""Build the ProofForge logo kit from the symbol geometry and the Space Grotesk wordmark.

Run from anywhere, in this order:
  python3 ProofForge-Logo-Kit-v1.0/08-source/build-kit.py
  python3 ProofForge-Logo-Kit-v1.0/08-source/build-docs.py
  python3 ProofForge-Logo-Kit-v1.0/08-source/build-motion.py
build-kit.py writes 01 to 06 and the geometry records in 07; build-docs.py writes the
gallery, overview, reference sheets, social card and guide; build-motion.py writes 09-motion
and the manifest. Requires fontTools, Pillow, rsvg-convert, ImageMagick (magick), macOS
iconutil for ICNS, and for the docs and motion steps Node 22 or later, headless Chrome and ffmpeg.
Fonts are read from 08-source/fonts. All text in the SVG masters and sheets is outlined here,
so no artwork depends on an installed font.
"""
from __future__ import annotations
import functools, hashlib, json, shutil, subprocess, sys, tempfile
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen

KIT = Path(__file__).resolve().parent.parent
SRC = KIT / '08-source'
FONTS = SRC / 'fonts'
BRAND = 'proofforge'
NAME = 'ProofForge'
VERSION = '1.0'
DATE = '2026-10-31'

# Palette accepted on 2026-10-31. The first twelve are the approved set; frost, hairline and
# white are supporting values taken from the proposal (the mark on dark, card edges on light).
C = {
    'void': '#05070B', 'graphite': '#0E131B', 'steel': '#1C2532', 'mist': '#A9B4C2',
    'forge': '#FF9A3C', 'forge-deep': '#D45F00', 'ion': '#5BE4F0', 'paper': '#F6F7F9',
    'verified': '#3DDC97', 'refuted': '#FF5D5D', 'ink': '#0B0F15', 'slate': '#4A5462',
    'frost': '#F2F5F8', 'hairline': '#E1E5EB', 'white': '#FFFFFF',
}

# The symbol on a 100 unit grid: two premises, the inference line, the conclusion block.
PREMISE_L = (14, 22, 30, 12, 1.5)
PREMISE_R = (56, 22, 30, 12, 1.5)
LINE = (8, 43, 84, 7, 0)
BLOCK = (39, 60, 22, 22, 1.5)
LINE_SMALL = (8, 42, 84, 10, 0)  # small cut: the line thickens to 10 units, gaps of 8 above and below
SMALL_CUT_UP_TO = 48
INK = (8, 22, 92, 82)  # x0, y0, x1, y1
INK_W, INK_H = INK[2] - INK[0], INK[3] - INK[1]

# Lockup rules (owner, 2026-10-31). Units: the wordmark font size is 100.
EM = 100.0
MARK_HEIGHT_EM = 0.78      # horizontal: mark ink height as a fraction of the font size
GAP_EM = 0.33              # horizontal: mark ink to wordmark ink
STACK_MARK_HEIGHT_EM = 1.25
STACK_GAP_EM = 0.36        # stacked: mark ink bottom to wordmark ink top
PAD = 8.0                  # artboard margin around the ink in every master
WORDMARK_TRACKING = -0.045

VARIANTS = {
    'primary': {'bars': C['ink'], 'block': C['forge-deep'], 'text': C['ink'], 'ground': C['paper']},
    'reversed': {'bars': C['frost'], 'block': C['forge'], 'text': C['frost'], 'ground': C['void']},
    'mono-ink': {'bars': C['ink'], 'block': C['ink'], 'text': C['ink'], 'ground': C['paper']},
    'mono-white': {'bars': C['white'], 'block': C['white'], 'text': C['white'], 'ground': C['void']},
}

# Faces used by the kit. Variable fonts are pinned to one instance each.
FACES = {
    'wordmark': ('SpaceGrotesk[wght].ttf', {'wght': 700}),
    'grotesk-700': ('SpaceGrotesk[wght].ttf', {'wght': 700}),
    'grotesk-600': ('SpaceGrotesk[wght].ttf', {'wght': 600}),
    'grotesk-500': ('SpaceGrotesk[wght].ttf', {'wght': 500}),
    'inter-400': ('Inter[opsz,wght].ttf', {'wght': 400, 'opsz': 14}),
    'inter-500': ('Inter[opsz,wght].ttf', {'wght': 500, 'opsz': 14}),
    'inter-600': ('Inter[opsz,wght].ttf', {'wght': 600, 'opsz': 14}),
    'mono-400': ('JetBrainsMono[wght].ttf', {'wght': 400}),
    'mono-500': ('JetBrainsMono[wght].ttf', {'wght': 500}),
    'serif': ('InstrumentSerif-Regular.ttf', None),
    'serif-italic': ('InstrumentSerif-Italic.ttf', None),
}


def fmt(v: float) -> str:
    s = f'{v:.3f}'.rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s


def run(*args: str) -> None:
    result = subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
    if result.returncode:
        sys.stderr.write(result.stderr)
        raise SystemExit(f'{args[0]} failed with status {result.returncode}')


# Type: outlines with GPOS pair kerning, the way a browser sets the same string
# (kerning on; ligatures off, as browsers drop them when letter spacing is set).

class Face:
    def __init__(self, key: str):
        file, axes = FACES[key]
        font = TTFont(FONTS / file)
        if axes:
            font = instantiateVariableFont(font, axes)
        self.font = font
        self.upm = font['head'].unitsPerEm
        self.cmap = font.getBestCmap()
        self.glyphs = font.getGlyphSet()
        self.hmtx = font['hmtx']
        self._kern: dict = {}
        self._lookups = []
        if 'GPOS' in font:
            gpos = font['GPOS'].table
            idx = set()
            for fr in gpos.FeatureList.FeatureRecord:
                if fr.FeatureTag == 'kern':
                    idx.update(fr.Feature.LookupListIndex)
            for i in sorted(idx):
                lk = gpos.LookupList.Lookup[i]
                subs = []
                for st in lk.SubTable:
                    if lk.LookupType == 9:
                        if st.ExtensionLookupType != 2:
                            continue
                        st = st.ExtSubTable
                    elif lk.LookupType != 2:
                        continue
                    subs.append(st)
                if subs:
                    self._lookups.append(subs)

    def glyph(self, ch: str) -> str:
        return self.cmap.get(ord(ch)) or self.cmap.get(ord('?'))

    def kern(self, g1: str, g2: str) -> float:
        key = (g1, g2)
        if key in self._kern:
            return self._kern[key]
        total = 0
        for subs in self._lookups:
            for st in subs:
                cov = st.Coverage.glyphs
                if g1 not in cov:
                    continue
                if st.Format == 1:
                    ps = st.PairSet[cov.index(g1)]
                    rec = next((r for r in ps.PairValueRecord if r.SecondGlyph == g2), None)
                    if rec is None:
                        continue
                    total += getattr(rec.Value1, 'XAdvance', 0) or 0 if rec.Value1 else 0
                    break
                c1 = st.ClassDef1.classDefs.get(g1, 0)
                c2 = st.ClassDef2.classDefs.get(g2, 0)
                rec = st.Class1Record[c1].Class2Record[c2]
                total += (getattr(rec.Value1, 'XAdvance', 0) or 0) if rec.Value1 else 0
                break
        self._kern[key] = total
        return total


@functools.lru_cache(maxsize=None)
def face(key: str) -> Face:
    return Face(key)


def layout(text: str, key: str, size: float, tracking_em: float = 0.0):
    """Glyph names and pen positions (in px at `size`) for one run, plus the advance width."""
    f = face(key)
    s = size / f.upm
    names = [f.glyph(ch) for ch in text]
    x = 0.0
    pos = []
    for i, n in enumerate(names):
        pos.append(x)
        adv = f.hmtx[n][0]
        if i + 1 < len(names):
            adv += f.kern(n, names[i + 1]) + tracking_em * f.upm
        x += adv * s
    return names, pos, x


def measure(text: str, key: str, size: float, tracking_em: float = 0.0) -> float:
    return layout(text, key, size, tracking_em)[2]


def outline(text: str, key: str, size: float, x: float = 0.0, y: float = 0.0, tracking_em: float = 0.0, anchor: str = 'start'):
    """Outline one run. Returns (path d, ink bounds (x0, y0, x1, y1) with y pointing down, advance)."""
    f = face(key)
    s = size / f.upm
    names, pos, adv = layout(text, key, size, tracking_em)
    if anchor == 'middle':
        x -= adv / 2
    elif anchor == 'end':
        x -= adv
    parts = []
    b = None
    for n, px in zip(names, pos):
        pen = SVGPathPen(f.glyphs, ntos=fmt)
        t = (s, 0, 0, -s, x + px, y)
        f.glyphs[n].draw(TransformPen(pen, t))
        parts.append(pen.getCommands())
        bp = BoundsPen(f.glyphs)
        f.glyphs[n].draw(TransformPen(bp, t))
        if bp.bounds:
            b = bp.bounds if b is None else (min(b[0], bp.bounds[0]), min(b[1], bp.bounds[1]),
                                             max(b[2], bp.bounds[2]), max(b[3], bp.bounds[3]))
    return ' '.join(p for p in parts if p), b, adv


def text_path(text: str, key: str, size: float, x: float, y: float, fill: str, tracking_em: float = 0.0,
              anchor: str = 'start', extra: str = '') -> str:
    d, _, _ = outline(text, key, size, x, y, tracking_em, anchor)
    return f'<path fill="{fill}"{extra} d="{d}"/>' if d else ''


def rich(runs, x: float, y: float, fill_default: str, anchor: str = 'start') -> str:
    """Outline a line made of runs: [(text, face, size, fill or None, tracking)]."""
    total = sum(measure(t, k, s, tr) for t, k, s, _, tr in runs)
    if anchor == 'middle':
        x -= total / 2
    elif anchor == 'end':
        x -= total
    out = []
    for t, k, s, fill, tr in runs:
        out.append(text_path(t, k, s, x, y, fill or fill_default, tr))
        x += measure(t, k, s, tr)
    return ''.join(out)


def wrap(text: str, key: str, size: float, width: float, tracking_em: float = 0.0) -> list[str]:
    lines, line = [], ''
    for w in text.split():
        trial = (line + ' ' + w).strip()
        if line and measure(trial, key, size, tracking_em) > width:
            lines.append(line)
            line = w
        else:
            line = trial
    if line:
        lines.append(line)
    return lines


def paragraph(text: str, key: str, size: float, x: float, y: float, width: float, fill: str, leading: float | None = None) -> tuple[str, float]:
    """Outline a wrapped paragraph; returns (markup, y of the last baseline)."""
    leading = leading or size * 1.5
    out = []
    for i, line in enumerate(wrap(text, key, size, width)):
        out.append(text_path(line, key, size, x, y + i * leading, fill))
    return ''.join(out), y + (len(out) - 1) * leading


# The symbol.

def rrect(x: float, y: float, w: float, h: float, r: float) -> str:
    if r <= 0:
        return f'M{fmt(x)} {fmt(y)}H{fmt(x + w)}V{fmt(y + h)}H{fmt(x)}Z'
    return (f'M{fmt(x + r)} {fmt(y)}H{fmt(x + w - r)}A{fmt(r)} {fmt(r)} 0 0 1 {fmt(x + w)} {fmt(y + r)}'
            f'V{fmt(y + h - r)}A{fmt(r)} {fmt(r)} 0 0 1 {fmt(x + w - r)} {fmt(y + h)}H{fmt(x + r)}'
            f'A{fmt(r)} {fmt(r)} 0 0 1 {fmt(x)} {fmt(y + h - r)}V{fmt(y + r)}A{fmt(r)} {fmt(r)} 0 0 1 {fmt(x + r)} {fmt(y)}Z')


def place(rect, k: float, ox: float, oy: float, snap: bool = False):
    """Map a grid rect to output coordinates. With snap, each edge moves to the nearest whole
    pixel (hinting for icons at 48 px and below); corner radii are kept."""
    x, y, w, h, r = rect
    x0, y0, x1, y1 = ox + k * x, oy + k * y, ox + k * (x + w), oy + k * (y + h)
    if snap:
        x0, y0, x1, y1 = round(x0), round(y0), round(x1), round(y1)
        r = r if k * r >= 0.5 else 0  # a radius under half a pixel only greys the corners
    return (x0, y0, x1 - x0, y1 - y0, min(k * r, (x1 - x0) / 2, (y1 - y0) / 2))


def symbol(bars: str, block: str, k: float = 1.0, ox: float = 0.0, oy: float = 0.0, small: bool = False,
           snap: bool = False) -> str:
    """The symbol in absolute coordinates: grid point (x, y) lands at (ox + k x, oy + k y)."""
    line = LINE_SMALL if small else LINE
    rects = [place(r, k, ox, oy, snap) for r in (PREMISE_L, PREMISE_R, line, BLOCK)]
    if snap:  # the gaps must stay open after snapping
        pl, pr, ln, bk = rects
        assert pr[0] - (pl[0] + pl[2]) >= 1 and ln[1] - (pl[1] + pl[3]) >= 1 and bk[1] - (ln[1] + ln[3]) >= 1, rects
    structure = ''.join(rrect(*r) for r in rects[:3])
    return f'<path fill="{bars}" d="{structure}"/><path fill="{block}" d="{rrect(*rects[3])}"/>'


def symbol_ink(bars: str, block: str, x: float, y: float, height: float, small: bool = False) -> str:
    """The symbol placed by its ink box: top left of the ink at (x, y), ink height `height`."""
    k = height / INK_H
    return symbol(bars, block, k, x - INK[0] * k, y - INK[1] * k, small)


@functools.lru_cache(maxsize=None)
def pixel_fit(size: int, small: bool, lo: float = 0.80, hi: float = 0.875) -> tuple[float, float, float]:
    """Scale and offset for a square icon of `size` px so the most symbol edges land on whole pixels.
    The ink width stays between lo and hi of the side; the ink box stays centred within a quarter pixel."""
    line = LINE_SMALL if small else LINE
    xs = [8, 14, 44, 56, 86, 92, 39, 61]
    ys = [22, 34, line[1], line[1] + line[3], 60, 82]
    best = None
    steps = 400
    for i in range(steps + 1):
        k = (lo + (hi - lo) * i / steps) * size / INK_W
        for dxi in range(-8, 9):
            ox = size / 2 - 50 * k + dxi / 32
            fx = sum(abs(ox + k * v - round(ox + k * v)) for v in xs)
            for dyi in range(-8, 9):
                oy = size / 2 - 52 * k + dyi / 32
                fy = sum(abs(oy + k * v - round(oy + k * v)) for v in ys)
                score = fx + fy + 0.6 * abs(k * INK_W / size - hi) + 0.05 * (abs(dxi) + abs(dyi)) / 8
                if best is None or score < best[0]:
                    best = (score, k, ox, oy)
    return best[1], best[2], best[3]


def svg(width: float, height: float, body: str, title: str, background: str | None = None, rx: float = 0) -> str:
    bg = ''
    if background:
        bg = f'<rect width="{fmt(width)}" height="{fmt(height)}"{f" rx={chr(34)}{fmt(rx)}{chr(34)}" if rx else ""} fill="{background}"/>'
    return (f'<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="{fmt(width)}" '
            f'height="{fmt(height)}" viewBox="0 0 {fmt(width)} {fmt(height)}" role="img" aria-labelledby="t">'
            f'<title id="t">{title}</title>{bg}{body}</svg>\n')


# Wordmark and lockups.

@functools.lru_cache(maxsize=None)
def wordmark():
    """'proofforge' in Space Grotesk 700 at 100 units per em, tracked -0.045em, baseline at y = 0."""
    d, b, adv = outline(BRAND, 'wordmark', EM, 0, 0, WORDMARK_TRACKING)
    return d, b, adv


def translate_path(d: str, dx: float, dy: float) -> str:
    return f'<g transform="translate({fmt(dx)} {fmt(dy)})">{d}</g>'


def wordmark_at(fill: str, x: float, y: float, size: float = EM) -> str:
    """The wordmark with its baseline origin at (x, y) and the given font size."""
    d, _, _ = wordmark()
    s = size / EM
    return f'<path transform="translate({fmt(x)} {fmt(y)}) scale({fmt(s) if s != 1 else 1})" fill="{fill}" d="{d}"/>'


@functools.lru_cache(maxsize=None)
def lockup_geometry() -> dict:
    """Positions computed from the outlined glyph bounds. Units: font size 100, baseline y = 0."""
    _, (wx0, wy0, wx1, wy1), _ = wordmark()
    word_cy = (wy0 + wy1) / 2
    mh = MARK_HEIGHT_EM * EM
    mw = mh * INK_W / INK_H
    gap = GAP_EM * EM
    mark = (0.0, word_cy - mh / 2, mw, word_cy + mh / 2)          # x0, y0, x1, y1 of the mark ink
    word_origin_x = mw + gap - wx0
    word = (word_origin_x + wx0, wy0, word_origin_x + wx1, wy1)
    ink = (0.0, min(mark[1], word[1]), word[2], max(mark[3], word[3]))
    horizontal = {
        'markInk': mark, 'wordInk': word, 'inkBox': ink, 'wordOriginX': word_origin_x,
        'markCentreY': (mark[1] + mark[3]) / 2, 'wordCentreY': word_cy,
        'width': ink[2] - ink[0] + 2 * PAD, 'height': ink[3] - ink[1] + 2 * PAD,
        'offset': (PAD - ink[0], PAD - ink[1]),
    }
    sh = STACK_MARK_HEIGHT_EM * EM
    sw = sh * INK_W / INK_H
    word_cx = (wx0 + wx1) / 2
    smark = (word_cx - sw / 2, wy0 - STACK_GAP_EM * EM - sh, word_cx + sw / 2, wy0 - STACK_GAP_EM * EM)
    sink = (min(smark[0], wx0), smark[1], max(smark[2], wx1), wy1)
    stacked = {
        'markInk': smark, 'wordInk': (wx0, wy0, wx1, wy1), 'inkBox': sink,
        'width': sink[2] - sink[0] + 2 * PAD, 'height': sink[3] - sink[1] + 2 * PAD,
        'offset': (PAD - sink[0], PAD - sink[1]),
    }
    return {'word': (wx0, wy0, wx1, wy1), 'horizontal': horizontal, 'stacked': stacked}


def horizontal_body(bars: str, block: str, text: str, ox: float = 0.0, oy: float = 0.0, scale: float = 1.0) -> str:
    """Horizontal lockup markup. (ox, oy) is the artboard origin; scale 1 means font size 100."""
    g = lockup_geometry()['horizontal']
    dx, dy = g['offset']
    m = g['markInk']
    mark = symbol_ink(bars, block, ox + scale * (m[0] + dx), oy + scale * (m[1] + dy), scale * (m[3] - m[1]))
    return mark + wordmark_at(text, ox + scale * (g['wordOriginX'] + dx), oy + scale * dy, EM * scale)


def stacked_body(bars: str, block: str, text: str, ox: float = 0.0, oy: float = 0.0, scale: float = 1.0) -> str:
    g = lockup_geometry()['stacked']
    dx, dy = g['offset']
    m = g['markInk']
    mark = symbol_ink(bars, block, ox + scale * (m[0] + dx), oy + scale * (m[1] + dy), scale * (m[3] - m[1]))
    return mark + wordmark_at(text, ox + scale * dx, oy + scale * dy, EM * scale)


def wordmark_body(text: str) -> tuple[float, float, str]:
    wx0, wy0, wx1, wy1 = lockup_geometry()['word']
    return wx1 - wx0 + 2 * PAD, wy1 - wy0 + 2 * PAD, wordmark_at(text, PAD - wx0, PAD - wy0)


def favicon_svg(size: int, small: bool, title: str) -> str:
    k, ox, oy = pixel_fit(size, small)
    return svg(size, size, symbol(C['frost'], C['forge'], k, ox, oy, small, snap=size <= SMALL_CUT_UP_TO), title, C['void'], rx=size * 0.1875)


def app_icon_svg(size: int, theme: str, small: bool, rounded: bool = False) -> str:
    bars, block, ground = (C['frost'], C['forge'], C['void']) if theme == 'dark' else (C['ink'], C['forge-deep'], C['paper'])
    snap = size <= SMALL_CUT_UP_TO
    if snap:
        k, ox, oy = pixel_fit(size, small, 0.78, 0.84)
    else:
        k = 0.60 * size / INK_W
        ox, oy = size / 2 - 50 * k, size / 2 - 52 * k
    body = symbol(bars, block, k, ox, oy, small, snap)
    title = f'{NAME} app icon, {theme}' + (', rounded preview' if rounded else '')
    return svg(size, size, body, title, ground, rx=size * 0.2237 if rounded else 0)


def build() -> dict:
    for d in ['01-vector', '02-png-transparent', '03-vector-pdf', '04-web', '05-app-icons', '06-brand-tokens']:
        shutil.rmtree(KIT / d, ignore_errors=True)
    (KIT / '07-reference').mkdir(exist_ok=True)
    geo = lockup_geometry()
    h, st = geo['horizontal'], geo['stacked']
    assert abs(h['markCentreY'] - h['wordCentreY']) < 1e-9
    for name, v in VARIANTS.items():
        vec = KIT / '01-vector' / name
        vec.mkdir(parents=True)
        files = {
            'icon': svg(100, 100, symbol(v['bars'], v['block']), f'{NAME} symbol, {name}'),
            'horizontal': svg(h['width'], h['height'], horizontal_body(v['bars'], v['block'], v['text']),
                              f'{NAME} horizontal lockup, {name}'),
            'stacked': svg(st['width'], st['height'], stacked_body(v['bars'], v['block'], v['text']),
                           f'{NAME} stacked lockup, {name}'),
        }
        ww, wh, wbody = wordmark_body(v['text'])
        files['wordmark'] = svg(ww, wh, wbody, f'{NAME} wordmark, {name}')
        for kind, text in files.items():
            (vec / f'{BRAND}-{kind}-{name}.svg').write_text(text)
    for name in VARIANTS:
        for kind in ['icon', 'wordmark', 'horizontal', 'stacked']:
            source = KIT / '01-vector' / name / f'{BRAND}-{kind}-{name}.svg'
            pdf = KIT / '03-vector-pdf' / name
            pdf.mkdir(parents=True, exist_ok=True)
            run('rsvg-convert', '-f', 'pdf', '-o', str(pdf / f'{BRAND}-{kind}-{name}.pdf'), str(source))
            png = KIT / '02-png-transparent' / name
            png.mkdir(parents=True, exist_ok=True)
            widths = [64, 128, 256, 512, 1024, 2048] if kind == 'icon' else [512, 1024, 2048, 4096]
            for w in widths:
                run('rsvg-convert', '-w', str(w), '-o', str(png / f'{BRAND}-{kind}-{name}-{w}w.png'), str(source))

    # Web. Favicons: a Void tile with rounded corners, the reversed symbol fitted to the pixel grid
    # per size; small cut up to 48 px. The SVG favicon carries the 16 px fit, which is whole-pixel at 32 too.
    web = KIT / '04-web'
    web.mkdir()
    (web / 'favicon.svg').write_text(favicon_svg(16, True, f'{NAME} favicon'))
    fits = {}
    with tempfile.TemporaryDirectory() as tmp:
        for s in [16, 24, 32, 48, 64, 96, 128, 256]:
            small = s <= SMALL_CUT_UP_TO
            f = Path(tmp) / f'fav-{s}.svg'
            f.write_text(favicon_svg(s, small, f'{NAME} favicon'))
            fits[s] = [round(v, 4) for v in pixel_fit(s, small)]
            run('rsvg-convert', '-w', str(s), '-h', str(s), '-o', str(web / f'favicon-{s}x{s}.png'), str(f))
    run('magick', *[str(web / f'favicon-{s}x{s}.png') for s in [16, 24, 32, 48, 64]], str(web / 'favicon.ico'))
    # Installable icons: full Void square, reversed symbol at 66% width; maskable keeps the
    # ink box inside the 80% safe circle (symbol at 56% width).
    k = 0.66 * 512 / INK_W
    (web / 'icon.svg').write_text(svg(512, 512, symbol(C['frost'], C['forge'], k, 256 - 50 * k, 256 - 52 * k), f'{NAME} app icon', C['void']))
    for s, out in [(180, 'apple-touch-icon.png'), (192, 'icon-192.png'), (512, 'icon-512.png')]:
        run('rsvg-convert', '-w', str(s), '-h', str(s), '-o', str(web / out), str(web / 'icon.svg'))
    k = 0.56 * 512 / INK_W
    (web / 'maskable-icon.svg').write_text(svg(512, 512, symbol(C['frost'], C['forge'], k, 256 - 50 * k, 256 - 52 * k), f'{NAME} maskable icon', C['void']))
    for s in [192, 512]:
        run('rsvg-convert', '-w', str(s), '-h', str(s), '-o', str(web / f'maskable-icon-{s}.png'), str(web / 'maskable-icon.svg'))
    (web / 'site.webmanifest').write_text(json.dumps({
        'name': NAME, 'short_name': NAME, 'start_url': '/', 'scope': '/', 'display': 'standalone',
        'background_color': C['void'], 'theme_color': C['void'],
        'icons': [{'src': 'icon-192.png', 'sizes': '192x192', 'type': 'image/png', 'purpose': 'any'},
                  {'src': 'icon-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'any'},
                  {'src': 'maskable-icon-192.png', 'sizes': '192x192', 'type': 'image/png', 'purpose': 'maskable'},
                  {'src': 'maskable-icon-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'maskable'}]}, indent=2) + '\n')
    (web / 'head-snippet.html').write_text(
        '<!-- Install all sizes together and version the URLs when they change. -->\n'
        '<link rel="icon" href="/favicon.ico" sizes="16x16 24x24 32x32 48x48 64x64">\n'
        '<link rel="icon" href="/brand/favicon.svg" type="image/svg+xml">\n'
        '<link rel="apple-touch-icon" href="/brand/apple-touch-icon.png">\n'
        f'<meta name="theme-color" content="{C["void"]}">\n'
        '<!-- Review routes and scope before using this example manifest. -->\n'
        '<link rel="manifest" href="/brand/site.webmanifest">\n'
        '<!-- Social card: replace the origin with the production address. -->\n'
        '<meta property="og:image" content="https://example.com/brand/og-image.png">\n'
        '<meta property="og:image:width" content="1200">\n'
        '<meta property="og:image:height" content="630">\n'
        '<meta property="og:image:alt" content="ProofForge. Muse writes the fix. Lean proves it.">\n'
        '<meta name="twitter:card" content="summary_large_image">\n')

    # Application icons: dark (Void) and light (Paper) full squares, rounded previews, ICO and ICNS.
    for theme in ['dark', 'light']:
        folder = KIT / '05-app-icons' / theme
        folder.mkdir(parents=True)
        (folder / f'{BRAND}-app-{theme}.svg').write_text(app_icon_svg(1024, theme, False))
        (folder / f'{BRAND}-app-{theme}-rounded-preview.svg').write_text(app_icon_svg(1024, theme, False, rounded=True))
        run('rsvg-convert', '-w', '512', '-h', '512', '-o', str(folder / f'{BRAND}-app-{theme}-rounded-preview-512.png'),
            str(folder / f'{BRAND}-app-{theme}-rounded-preview.svg'))
        for s in [64, 128, 180, 192, 256, 512, 1024]:
            run('rsvg-convert', '-w', str(s), '-h', str(s), '-o', str(folder / f'{BRAND}-app-{theme}-{s}.png'),
                str(folder / f'{BRAND}-app-{theme}.svg'))
        with tempfile.TemporaryDirectory() as tmp:
            frames = []
            for s in [16, 24, 32, 48, 64, 128, 256]:
                f = Path(tmp) / f'app-{s}.svg'
                f.write_text(app_icon_svg(s, theme, s <= SMALL_CUT_UP_TO))
                out = Path(tmp) / f'app-{s}.png'
                run('rsvg-convert', '-w', str(s), '-h', str(s), '-o', str(out), str(f))
                frames.append(str(out))
            run('magick', *frames, str(folder / f'{BRAND}-{theme}.ico'))
            if shutil.which('iconutil'):
                iconset = Path(tmp) / 'icon.iconset'
                iconset.mkdir()
                for s in [16, 32, 128, 256, 512]:
                    for scale, suffix in [(1, ''), (2, '@2x')]:
                        px = s * scale
                        f = Path(tmp) / f'icns-{px}.svg'
                        f.write_text(app_icon_svg(px, theme, px <= SMALL_CUT_UP_TO))
                        run('rsvg-convert', '-w', str(px), '-h', str(px), '-o', str(iconset / f'icon_{s}x{s}{suffix}.png'), str(f))
                run('iconutil', '-c', 'icns', '-o', str(folder / f'{BRAND}-{theme}.icns'), str(iconset))

    # Tokens.
    tokens = KIT / '06-brand-tokens'
    tokens.mkdir()
    roles = {
        'light': {'ground': 'paper', 'surface': 'white', 'edge': 'hairline', 'text': 'ink', 'body': 'slate',
                  'mark': 'ink', 'block': 'forge-deep', 'accent': 'forge-deep', 'code': 'ink', 'graph': 'ink',
                  'verified': 'verified', 'refuted': 'refuted', 'onVerdict': 'ink'},
        'dark': {'ground': 'void', 'surface': 'graphite', 'edge': 'steel', 'text': 'frost', 'body': 'mist',
                 'mark': 'frost', 'block': 'forge', 'accent': 'forge', 'code': 'ion', 'graph': 'ion',
                 'verified': 'verified', 'refuted': 'refuted', 'onVerdict': 'ink'},
    }
    fonts = {
        'headline': {'family': 'Instrument Serif', 'stack': "'Instrument Serif', Georgia, serif", 'use': 'page headlines'},
        'display': {'family': 'Space Grotesk', 'stack': "'Space Grotesk', Inter, system-ui, sans-serif", 'weights': [500, 600, 700],
                    'use': 'wordmark, figures, section titles'},
        'interface': {'family': 'Inter', 'stack': 'Inter, system-ui, sans-serif', 'weights': [400, 500, 600], 'use': 'interface and body'},
        'mono': {'family': 'JetBrains Mono', 'stack': "'JetBrains Mono', ui-monospace, monospace", 'weights': [400, 500],
                 'use': 'Lean, hashes, Passport readings'},
    }
    r4 = lambda t: [round(v, 4) for v in t]
    (tokens / f'{BRAND}-tokens.json').write_text(json.dumps({
        'brand': NAME, 'version': VERSION, 'colorSpace': 'sRGB',
        'colors': C,
        'colorUse': {
            'void': 'page ground in dark', 'graphite': 'cards and panels on dark', 'steel': 'card edges on dark',
            'mist': 'body text on dark', 'forge': 'the block on dark; one accent per view',
            'forge-deep': 'the block on light; large accents on light', 'ion': 'proof graphs and Lean code on dark',
            'paper': 'page ground in light', 'verified': 'the verified verdict only', 'refuted': 'the refuted verdict only',
            'ink': 'text and mark on light', 'slate': 'body text on light', 'frost': 'the mark and headings on dark',
            'hairline': 'card edges on light', 'white': 'cards on light; the mono white mark',
        },
        'themes': roles,
        'typography': fonts,
        'symbol': {
            'grid': 100, 'premises': [PREMISE_L, PREMISE_R], 'line': LINE, 'block': BLOCK,
            'rectFormat': 'x, y, width, height, corner radius', 'inkBox': INK,
            'small': {'line': LINE_SMALL, 'upToPx': SMALL_CUT_UP_TO},
        },
        'wordmark': {'text': BRAND, 'face': 'Space Grotesk 700', 'trackingEm': WORDMARK_TRACKING, 'unitsPerEm': EM,
                     'inkBox': r4(geo['word']), 'note': 'y points down; baseline at y = 0'},
        'lockups': {
            'horizontal': {'markHeightEm': MARK_HEIGHT_EM, 'gapEm': GAP_EM, 'rule': 'mark ink centre level with the wordmark ink centre',
                           'markInk': r4(h['markInk']), 'wordInk': r4(h['wordInk']), 'artboard': r4((h['width'], h['height']))},
            'stacked': {'markHeightEm': STACK_MARK_HEIGHT_EM, 'gapEm': STACK_GAP_EM, 'rule': 'mark ink centred above the wordmark ink',
                        'markInk': r4(st['markInk']), 'wordInk': r4(st['wordInk']), 'artboard': r4((st['width'], st['height']))},
            'artboardPad': PAD,
        },
        'favicon': {'tile': C['void'], 'cornerRadiusRatio': 0.1875, 'smallCutUpToPx': SMALL_CUT_UP_TO,
                    'pixelFit': {str(s): v for s, v in fits.items()}, 'pixelFitFormat': 'scale, offset x, offset y in px'},
    }, indent=2) + '\n')
    css = ['/* ProofForge brand tokens v1.0. Light is the default; dark follows the system or data-theme="dark". */', ':root {']
    css += [f'  --proofforge-{k}: {v.lower()};' for k, v in C.items()]
    css += [f'  --pf-font-{k}: {v["stack"]};' for k, v in fonts.items()]
    kebab = lambda name: ''.join('-' + ch.lower() if ch.isupper() else ch for ch in name)
    css += [f'  --pf-{kebab(k)}: var(--proofforge-{v});' for k, v in roles['light'].items()]
    css += ['  color-scheme: light;', '}']
    dark = [f'  --pf-{kebab(k)}: var(--proofforge-{v});' for k, v in roles['dark'].items()] + ['  color-scheme: dark;']
    css += ['@media (prefers-color-scheme: dark) {', '  :root:not([data-theme="light"]) {'] + ['  ' + l for l in dark] + ['  }', '}']
    css += [':root[data-theme="dark"] {'] + dark + ['}']
    (tokens / f'{BRAND}-tokens.css').write_text('\n'.join(css) + '\n')

    (KIT / '07-reference' / f'{BRAND}-symbol-primary.svg').write_text(
        svg(100, 100, symbol(C['ink'], C['forge-deep']), f'{NAME} symbol, primary, reference'))
    (KIT / '07-reference' / f'{BRAND}-symbol-small-cut.svg').write_text(
        svg(100, 100, symbol(C['ink'], C['forge-deep'], small=True), f'{NAME} symbol, small cut for 48 px and below'))
    return {'wordmarkInk': r4(geo['word']), 'horizontal': {k: (r4(v) if isinstance(v, tuple) else round(v, 4)) for k, v in h.items()},
            'stacked': {k: (r4(v) if isinstance(v, tuple) else round(v, 4)) for k, v in st.items()}, 'faviconFits': fits}


def manifest() -> None:
    entries = {}
    for path in sorted(KIT.rglob('*')):
        if path.is_file() and path.name not in ('manifest-sha256.json', '.DS_Store') and '__pycache__' not in path.parts:
            rel = path.relative_to(KIT).as_posix()
            data = path.read_bytes()
            entries[rel] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    (KIT / 'manifest-sha256.json').write_text(json.dumps(entries, indent=2) + '\n')


if __name__ == '__main__':
    info = build()
    print(json.dumps(info, indent=1))
    if '--manifest' in sys.argv:
        manifest()
