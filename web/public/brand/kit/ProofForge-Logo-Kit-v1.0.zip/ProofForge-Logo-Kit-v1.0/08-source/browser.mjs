#!/usr/bin/env node
// Drive headless Chrome over the DevTools protocol for the kit builds: page screenshots,
// PDF printing, JavaScript measurements and deterministic animation frames.
// Needs Node 22 or later (built-in WebSocket) and Chrome or chrome-headless-shell.
// Set CHROME to a browser binary to override the search.
//
// Usage: node browser.mjs jobs.json
// jobs.json: {"tasks": [{"type": "shot" | "pdf" | "eval" | "frames", ...}]}
//   shot:   url, width, height, out, scale = 1, full = false, reducedMotion = false, atMs (pause animations there)
//   pdf:    url, out (paper size and margins come from the page's @page rule)
//   eval:   url, width, height, expr, out (writes the JSON value of expr)
//   frames: url, width, height, fps, durationMs, outdir (frame-00000.png ...)
import { spawn } from 'node:child_process';
import { mkdtempSync, writeFileSync, rmSync, mkdirSync, readFileSync, existsSync, readdirSync } from 'node:fs';
import { tmpdir, homedir } from 'node:os';
import { join } from 'node:path';

function findChrome() {
  if (process.env.CHROME) return process.env.CHROME;
  const cache = join(homedir(), 'Library', 'Caches', 'ms-playwright');
  if (existsSync(cache)) {
    const shells = readdirSync(cache).filter((d) => d.startsWith('chromium_headless_shell-')).sort(
      (a, b) => Number(b.split('-')[1]) - Number(a.split('-')[1]));
    for (const d of shells) {
      for (const arch of ['chrome-headless-shell-mac-arm64', 'chrome-headless-shell-mac-x64', 'chrome-headless-shell-linux64']) {
        const p = join(cache, d, arch, 'chrome-headless-shell');
        if (existsSync(p)) return p;
      }
    }
  }
  for (const p of ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/usr/bin/google-chrome', '/usr/bin/chromium']) {
    if (existsSync(p)) return p;
  }
  throw new Error('No Chrome found; set CHROME to a Chrome or chrome-headless-shell binary.');
}

class Browser {
  async launch() {
    const bin = findChrome();
    this.profile = mkdtempSync(join(tmpdir(), 'pf-chrome-'));
    const args = ['--remote-debugging-port=0', `--user-data-dir=${this.profile}`, '--no-first-run',
      '--no-default-browser-check', '--hide-scrollbars', '--force-color-profile=srgb', '--font-render-hinting=none',
      '--allow-file-access-from-files', '--disable-background-timer-throttling', '--disable-renderer-backgrounding',
      bin.includes('headless-shell') ? '--headless' : '--headless=new', 'about:blank'];
    this.proc = spawn(bin, args, { stdio: ['ignore', 'ignore', 'pipe'] });
    const wsUrl = await new Promise((resolve, reject) => {
      let buf = '';
      this.proc.stderr.on('data', (d) => {
        buf += d.toString();
        const m = buf.match(/DevTools listening on (ws:\/\/\S+)/);
        if (m) resolve(m[1]);
      });
      this.proc.on('exit', (c) => reject(new Error(`Chrome exited with ${c}: ${buf}`)));
    });
    this.ws = new WebSocket(wsUrl);
    this.id = 0;
    this.pending = new Map();
    this.listeners = [];
    await new Promise((r) => this.ws.addEventListener('open', r, { once: true }));
    this.ws.addEventListener('message', (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result);
      } else if (msg.method) {
        for (const l of this.listeners) l(msg);
      }
    });
  }

  send(method, params = {}, sessionId) {
    const id = ++this.id;
    this.ws.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
    return new Promise((resolve, reject) => this.pending.set(id, { resolve, reject }));
  }

  waitFor(method, sessionId) {
    return new Promise((resolve) => {
      const l = (msg) => {
        if (msg.method === method && msg.sessionId === sessionId) {
          this.listeners.splice(this.listeners.indexOf(l), 1);
          resolve(msg.params);
        }
      };
      this.listeners.push(l);
    });
  }

  async page(task) {
    const { targetId } = await this.send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await this.send('Target.attachToTarget', { targetId, flatten: true });
    const s = (m, p) => this.send(m, p, sessionId);
    await s('Page.enable');
    await s('Runtime.enable');
    await s('Emulation.setDeviceMetricsOverride', {
      width: task.width || 1280, height: task.height || 800, deviceScaleFactor: task.scale || 1, mobile: false });
    await s('Emulation.setEmulatedMedia', {
      features: [{ name: 'prefers-reduced-motion', value: task.reducedMotion ? 'reduce' : 'no-preference' },
        { name: 'prefers-color-scheme', value: task.colorScheme || 'light' }] });
    const loaded = this.waitFor('Page.loadEventFired', sessionId);
    await s('Page.navigate', { url: task.url });
    await loaded;
    const evaluate = async (expression) => {
      const r = await s('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
      if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails));
      return r.result.value;
    };
    await evaluate('document.fonts.ready.then(() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))))');
    return { s, evaluate, close: () => this.send('Target.closeTarget', { targetId }) };
  }

  async close() {
    try { this.ws.close(); } catch {}
    this.proc.kill();
    await new Promise((r) => setTimeout(r, 200));
    rmSync(this.profile, { recursive: true, force: true });
  }
}

const SEEK = (ms) => `(() => { for (const a of document.getAnimations()) { a.pause(); a.currentTime = ${ms}; }
  return new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))); })()`;

async function run(task, b) {
  const p = await b.page(task);
  try {
    if (task.type === 'shot') {
      if (task.atMs !== undefined) await p.evaluate(SEEK(task.atMs));
      let clip;
      if (task.full) {
        const m = await p.s('Page.getLayoutMetrics');
        const h = Math.ceil(m.cssContentSize.height);
        clip = { x: 0, y: 0, width: task.width, height: h, scale: 1 };
      }
      const r = await p.s('Page.captureScreenshot', { format: 'png', captureBeyondViewport: !!task.full, ...(clip ? { clip } : {}) });
      writeFileSync(task.out, Buffer.from(r.data, 'base64'));
    } else if (task.type === 'pdf') {
      const r = await p.s('Page.printToPDF', { printBackground: true, preferCSSPageSize: true, displayHeaderFooter: false });
      writeFileSync(task.out, Buffer.from(r.data, 'base64'));
    } else if (task.type === 'eval') {
      const v = await p.evaluate(task.expr);
      writeFileSync(task.out, JSON.stringify(v, null, 2) + '\n');
    } else if (task.type === 'frames') {
      mkdirSync(task.outdir, { recursive: true });
      const n = Math.round(task.durationMs * task.fps / 1000);
      for (let i = 0; i <= n; i++) {
        await p.evaluate(SEEK((i * 1000) / task.fps));
        const r = await p.s('Page.captureScreenshot', { format: 'png' });
        writeFileSync(join(task.outdir, `frame-${String(i).padStart(5, '0')}.png`), Buffer.from(r.data, 'base64'));
      }
    }
  } finally {
    await p.close();
  }
}

const jobs = JSON.parse(readFileSync(process.argv[2], 'utf8'));
const b = new Browser();
await b.launch();
try {
  for (const t of jobs.tasks) await run(t, b);
} finally {
  await b.close();
}
