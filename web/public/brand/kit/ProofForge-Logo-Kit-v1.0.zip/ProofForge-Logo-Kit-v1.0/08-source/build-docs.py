#!/usr/bin/env python3
"""Build the kit's overview sheet, reference sheets, social card, guide PDF, gallery and
acceptance record from the assets that build-kit.py generated. Run after build-kit.py.

Sheets are SVG with every word outlined from 08-source/fonts, rendered with rsvg-convert.
The guide is HTML printed to PDF by headless Chrome (08-source/browser.mjs, Node 22 or later),
so its text stays selectable and set in the brand faces. Writes manifest-sha256.json last.
"""
from __future__ import annotations
import importlib.util, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path
from PIL import Image

SRC = Path(__file__).resolve().parent
_spec = importlib.util.spec_from_file_location('build_kit', SRC / 'build-kit.py')
K = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(K)

KIT = SRC.parent
C = K.C
NAME, BRAND = K.NAME, K.BRAND
TAGLINE = 'Muse writes the fix. Lean proves it.'
GEO = K.lockup_geometry()
NODE = os.environ.get('NODE', 'node')


def node_bin() -> str:
    """Node 22 or later is needed for the built-in WebSocket used by browser.mjs."""
    candidates = [os.environ.get('NODE', ''), shutil.which('node') or '']
    nvm = Path.home() / '.nvm' / 'versions' / 'node'
    if nvm.exists():
        candidates += [str(p / 'bin' / 'node') for p in sorted(nvm.iterdir(), reverse=True)]
    for c in candidates:
        if not c:
            continue
        try:
            v = subprocess.run([c, '-v'], capture_output=True, text=True).stdout.strip().lstrip('v')
        except OSError:
            continue
        if v and int(v.split('.')[0]) >= 22:
            return c
    raise SystemExit('Node 22 or later is required for browser.mjs (set NODE).')


def browser(tasks: list[dict]) -> None:
    with tempfile.TemporaryDirectory() as tmp:
        jobs = Path(tmp) / 'jobs.json'
        jobs.write_text(json.dumps({'tasks': tasks}))
        subprocess.run([node_bin(), str(SRC / 'browser.mjs'), str(jobs)], check=True)


def sheet(w: float, h: float, body: str, title: str) -> str:
    return (f'<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="{K.fmt(w)}" height="{K.fmt(h)}" '
            f'viewBox="0 0 {K.fmt(w)} {K.fmt(h)}" role="img" aria-labelledby="t"><title id="t">{title}</title>{body}</svg>\n')


def render(svg_text: str, out: Path, width: int) -> None:
    with tempfile.TemporaryDirectory() as tmp:
        f = Path(tmp) / 'sheet.svg'
        f.write_text(svg_text)
        subprocess.run(['rsvg-convert', '-w', str(width), '-o', str(out), str(f)], check=True)


T = K.text_path  # (text, face, size, x, y, fill, tracking, anchor)


def horizontal(variant: str, x: float, y: float, width: float) -> str:
    v = K.VARIANTS[variant]
    s = width / GEO['horizontal']['width']
    return K.horizontal_body(v['bars'], v['block'], v['text'], x, y, s)


def horizontal_size(width: float) -> tuple[float, float]:
    g = GEO['horizontal']
    return width, width * g['height'] / g['width']


def stacked(variant: str, x: float, y: float, width: float) -> str:
    v = K.VARIANTS[variant]
    s = width / GEO['stacked']['width']
    return K.stacked_body(v['bars'], v['block'], v['text'], x, y, s)


def card(x, y, w, h, fill, stroke=None, rx=24):
    st = f' stroke="{stroke}" stroke-width="1"' if stroke else ''
    return f'<rect x="{K.fmt(x)}" y="{K.fmt(y)}" width="{K.fmt(w)}" height="{K.fmt(h)}" rx="{rx}" fill="{fill}"{st}/>'


def anatomy(x: float, y: float, height: float, label_x: float, bars: str, block: str, label_fill: str, lead: str, size: float = 15) -> str:
    """The symbol with its three labels: premises, inference line, conclusion."""
    k = height / K.INK_H
    out = [K.symbol_ink(bars, block, x, y, height)]
    rows = [((22 + 34) / 2, 'premises', lead), ((43 + 50) / 2, 'inference line', lead), ((60 + 82) / 2, 'conclusion: proved', block)]
    for gy, label, stroke in rows:
        yy = y + (gy - K.INK[1]) * k
        out.append(f'<path d="M{K.fmt(label_x)} {K.fmt(yy)}H{K.fmt(label_x + 22)}" stroke="{stroke}" stroke-width="1.5"/>')
        out.append(T(label, 'mono-500', size, label_x + 34, yy + size * 0.36, label_fill))
    return ''.join(out)


SWATCHES = [('Void', 'void'), ('Graphite', 'graphite'), ('Steel', 'steel'), ('Mist', 'mist'), ('Forge', 'forge'),
            ('Forge deep', 'forge-deep'), ('Ion', 'ion'), ('Paper', 'paper'), ('Verified', 'verified'), ('Refuted', 'refuted'),
            ('Ink', 'ink'), ('Slate', 'slate')]


def overview() -> str:
    W, H = 1600, 1120
    p = [f'<rect width="{W}" height="{H}" fill="{C["void"]}"/>']
    p.append(T('ProofForge identity kit, version 1.0, accepted 2026-10-31', 'inter-500', 16, 64, 66, C['mist']))
    p.append(card(64, 96, 1472, 400, C['paper']))
    w, h = horizontal_size(1000)
    p.append(horizontal('primary', 800 - w / 2, 296 - h / 2, w))
    p.append(card(64, 528, 960, 280, C['graphite'], C['steel']))
    w, h = horizontal_size(700)
    p.append(horizontal('reversed', 544 - w / 2, 668 - h / 2, w))
    p.append(card(1056, 528, 480, 280, C['graphite'], C['steel']))
    p.append(anatomy(1100, 608, 120, 1290, C['frost'], C['forge'], C['mist'], C['ion']))
    x, sw, gap = 64.0, 108.0, (1472 - 12 * 108) / 11
    for label, key in SWATCHES:
        p.append(card(x, 848, sw, 64, C[key], C['steel'], 12))
        p.append(T(label, 'inter-600', 13, x, 938, C['frost']))
        p.append(T(C[key], 'mono-400', 12, x, 958, C['mist']))
        x += sw + gap
    p.append(T(TAGLINE, 'serif', 46, 64, 1052, C['frost']))
    p.append(T('Instrument Serif, Space Grotesk, Inter and JetBrains Mono', 'inter-400', 14, 1536, 1036, C['mist'], anchor='end'))
    p.append(T('One accent per view: the Forge block.', 'inter-400', 14, 1536, 1058, C['mist'], anchor='end'))
    return sheet(W, H, ''.join(p), f'{NAME} identity overview')


def construction() -> str:
    """The grid, the symbol geometry and the lockup alignment rule, measured."""
    W, H = 1600, 1200
    p = [f'<rect width="{W}" height="{H}" fill="{C["paper"]}"/>']
    p.append(T('Construction and alignment', 'serif', 48, 64, 92, C['ink']))
    p.append(T('Geometry on the 100 unit grid, and lockup positions computed from the outlined glyph bounds.', 'inter-400', 17, 64, 128, C['slate']))
    # Left: the grid.
    p.append(card(64, 160, 640, 640 + 20, C['white'], C['hairline']))
    gx, gy, gs = 124, 196, 5.2  # grid origin and px per unit
    for i in range(0, 101, 10):
        p.append(f'<path d="M{K.fmt(gx + i * gs)} {gy}V{K.fmt(gy + 100 * gs)}M{gx} {K.fmt(gy + i * gs)}H{K.fmt(gx + 100 * gs)}" stroke="{C["hairline"]}" stroke-width="1"/>')
    x0, y0, x1, y1 = K.INK
    p.append(f'<rect x="{K.fmt(gx + x0 * gs)}" y="{K.fmt(gy + y0 * gs)}" width="{K.fmt((x1 - x0) * gs)}" height="{K.fmt((y1 - y0) * gs)}" '
             f'fill="none" stroke="{C["slate"]}" stroke-width="1" stroke-dasharray="5 4"/>')
    p.append(K.symbol(C['ink'], C['forge-deep'], gs, gx, gy))
    notes = [('14, 22, 30 x 12', 14, 18.5), ('56, 22, 30 x 12', 56, 18.5), ('8, 43, 84 x 7', 10, 40),
             ('39, 60, 22 x 22', 39, 88)]
    for label, ux, uy in notes:
        p.append(T(label, 'mono-400', 13, gx + ux * gs, gy + uy * gs, C['slate']))
    p.append(T('Rects: x, y, width x height. Corner radius 1.5 on the premises and the block.', 'inter-400', 14, gx, gy + 100 * gs + 34, C['slate']))
    p.append(T('Ink box (dashed): x 8 to 92, y 22 to 82, 84 x 60.', 'inter-400', 14, gx, gy + 100 * gs + 56, C['slate']))
    # Right: the horizontal lockup and its rule.
    p.append(card(736, 160, 800, 660, C['white'], C['hairline']))
    g = GEO['horizontal']
    m, wd = g['markInk'], g['wordInk']
    p.append(alignment_markup(840, 280, 560, 12))
    ty = 548
    rows = [
        ('Mark height', f'0.78 of the font size ({K.fmt(m[3] - m[1])} units at size 100)'),
        ('Wordmark ink', f'top {K.fmt(wd[1])} (f), bottom {K.fmt(wd[3])} (p, g), centre {K.fmt(g["wordCentreY"])}'),
        ('Mark ink', f'top {K.fmt(m[1])}, bottom {K.fmt(m[3])}, centre {K.fmt(g["markCentreY"])}'),
        ('Rule', 'mark centre level with the wordmark ink centre, 0.25 em above the baseline'),
        ('Gap', f'0.33 em from mark ink to wordmark ink ({K.fmt(wd[0] - m[2])} units)'),
    ]
    for i, (a, b) in enumerate(rows):
        p.append(T(a, 'inter-600', 15, 776, ty + i * 38, C['ink']))
        p.append(T(b, 'inter-400', 15, 906, ty + i * 38, C['slate']))
    p.append(T('Units: font size 100, y down from the baseline. Ink centre lines in Forge deep.', 'inter-400', 13, 776, 788, C['slate']))
    # Bottom: stacked lockup, and master versus small cut.
    p.append(card(64, 852, 720, 300, C['white'], C['hairline']))
    st = GEO['stacked']
    sw = 300
    sx, sy = 424 - sw / 2, 876
    p.append(stacked('primary', sx, sy, sw))
    ss = sw / st['width']
    sm = st['markInk']
    axis = sx + (sm[0] + sm[2]) / 2 * ss + st['offset'][0] * ss
    p.append(f'<path d="M{K.fmt(axis)} {sy - 6}V{K.fmt(sy + st["height"] * ss + 6)}" stroke="{C["forge-deep"]}" stroke-width="1" stroke-dasharray="4 3"/>')
    p.append(T('Stacked: the mark, 1.25 em high, centred above', 'inter-400', 14, 424, 1102, C['slate'], anchor='middle'))
    p.append(T('the wordmark ink, 0.36 em above the f.', 'inter-400', 14, 424, 1124, C['slate'], anchor='middle'))
    p.append(card(816, 852, 720, 300, C['white'], C['hairline']))
    p.append(K.symbol(C['ink'], C['forge-deep'], 1.7, 870, 880))
    p.append(K.symbol(C['ink'], C['forge-deep'], 1.7, 1200, 880, small=True))
    p.append(T('Master: line 7 units', 'inter-600', 15, 955, 1080, C['ink'], anchor='middle'))
    p.append(T('above 48 px', 'inter-400', 14, 955, 1104, C['slate'], anchor='middle'))
    p.append(T('Small cut: line 10 units', 'inter-600', 15, 1285, 1080, C['ink'], anchor='middle'))
    p.append(T('48 px and below, gaps of 8', 'inter-400', 14, 1285, 1104, C['slate'], anchor='middle'))
    return sheet(W, H, ''.join(p), f'{NAME} construction and alignment')


def alignment_markup(lx: float, ly: float, lw: float, fs: float) -> str:
    """The primary horizontal lockup at width lw with its measured guides; fs is the label size."""
    p = [horizontal('primary', lx, ly, lw)]
    g = GEO['horizontal']
    s = lw / g['width']
    dx, dy = g['offset']
    Y = lambda u: ly + (u + dy) * s
    X = lambda u: lx + (u + dx) * s
    m, wd = g['markInk'], g['wordInk']
    right = lx + lw + fs
    sw = max(1, fs / 12)
    for u, label, dash in [(wd[1], 'top of f', '4 4'), (0, 'baseline', '1 3'), (wd[3], 'bottom of p, g', '4 4')]:
        p.append(f'<path d="M{K.fmt(X(m[0]) - fs)} {K.fmt(Y(u))}H{K.fmt(right)}" stroke="{C["slate"]}" stroke-width="{sw}" stroke-dasharray="{dash}"/>')
        p.append(T(label, 'mono-400', fs, right + fs * 0.7, Y(u) + fs * 0.35, C['slate']))
    for u in (m[1], m[3]):
        p.append(f'<path d="M{K.fmt(X(m[0]) - 1.5 * fs)} {K.fmt(Y(u))}H{K.fmt(X(m[2]) + fs / 2)}" stroke="{C["slate"]}" stroke-width="{sw}" stroke-dasharray="2 3"/>')
    cy = Y(g['wordCentreY'])
    p.append(f'<path d="M{K.fmt(X(m[0]) - fs)} {K.fmt(cy)}H{K.fmt(right)}" stroke="{C["forge-deep"]}" stroke-width="{1.5 * sw}"/>')
    p.append(T('ink centre', 'mono-500', fs, right + fs * 0.7, cy + fs * 0.35, C['forge-deep']))
    mx = X(m[0]) - 1.5 * fs
    p.append(f'<path d="M{K.fmt(mx)} {K.fmt(Y(m[1]))}V{K.fmt(Y(m[3]))}" stroke="{C["ink"]}" stroke-width="{sw}"/>')
    p.append(T('0.78 em', 'mono-400', fs, mx - fs * 0.7, cy + fs * 0.35, C['ink'], anchor='end'))
    gy2 = Y(wd[3]) + 2.5 * fs
    t = fs * 0.4
    p.append(f'<path d="M{K.fmt(X(m[2]))} {K.fmt(gy2)}H{K.fmt(X(wd[0]))}M{K.fmt(X(m[2]))} {K.fmt(gy2 - t)}V{K.fmt(gy2 + t)}M{K.fmt(X(wd[0]))} {K.fmt(gy2 - t)}V{K.fmt(gy2 + t)}" stroke="{C["ink"]}" stroke-width="{sw}"/>')
    p.append(T('0.33 em', 'mono-400', fs, (X(m[2]) + X(wd[0])) / 2, gy2 + 1.8 * fs, C['ink'], anchor='middle'))
    return ''.join(p)


def alignment_sheet() -> str:
    W, H = 1480, 330
    body = f'<rect width="{W}" height="{H}" fill="{C["white"]}"/>' + alignment_markup(150, 40, 1080, 20)
    return sheet(W, H, body, f'{NAME} horizontal lockup alignment rule')


def clear_space_sheet() -> str:
    """Clear space of half the symbol height around both lockups."""
    W, H = 1600, 400
    p = [f'<rect width="{W}" height="{H}" fill="{C["white"]}"/>']
    g = GEO['horizontal']
    lw = 820
    s = lw / g['width']
    m = g['markInk']
    cs = (m[3] - m[1]) / 2 * s
    ink = g['inkBox']
    dx, dy = g['offset']
    x0 = 100 + cs
    y0 = 70 + cs - (ink[1] + dy) * s
    ix0, iy0 = x0 + (ink[0] + dx) * s, y0 + (ink[1] + dy) * s
    ix1, iy1 = x0 + (ink[2] + dx) * s, y0 + (ink[3] + dy) * s
    p.append(f'<rect x="{K.fmt(ix0 - cs)}" y="{K.fmt(iy0 - cs)}" width="{K.fmt(ix1 - ix0 + 2 * cs)}" height="{K.fmt(iy1 - iy0 + 2 * cs)}" fill="{C["paper"]}" stroke="{C["slate"]}" stroke-dasharray="5 4"/>')
    p.append(f'<rect x="{K.fmt(ix0)}" y="{K.fmt(iy0)}" width="{K.fmt(ix1 - ix0)}" height="{K.fmt(iy1 - iy0)}" fill="{C["white"]}"/>')
    p.append(horizontal('primary', x0, y0, lw))
    p.append(f'<path d="M{K.fmt(ix0 - cs)} {K.fmt(iy1 + cs + 26)}H{K.fmt(ix0)}M{K.fmt(ix0 - cs)} {K.fmt(iy1 + cs + 20)}V{K.fmt(iy1 + cs + 32)}M{K.fmt(ix0)} {K.fmt(iy1 + cs + 20)}V{K.fmt(iy1 + cs + 32)}" stroke="{C["ink"]}" stroke-width="1.5"/>')
    p.append(T('clear space: half the symbol height', 'mono-400', 20, ix0 + 16, iy1 + cs + 33, C['ink']))
    st = GEO['stacked']
    sw = 280
    ss = sw / st['width']
    sm = st['markInk']
    scs = (sm[3] - sm[1]) / 2 * ss
    sink = st['inkBox']
    sdx, sdy = st['offset']
    sx0 = 1200
    sy0 = 70 + scs - (sink[1] + sdy) * ss
    a0, b0 = sx0 + (sink[0] + sdx) * ss, sy0 + (sink[1] + sdy) * ss
    a1, b1 = sx0 + (sink[2] + sdx) * ss, sy0 + (sink[3] + sdy) * ss
    p.append(f'<rect x="{K.fmt(a0 - scs)}" y="{K.fmt(b0 - scs)}" width="{K.fmt(a1 - a0 + 2 * scs)}" height="{K.fmt(b1 - b0 + 2 * scs)}" fill="{C["paper"]}" stroke="{C["slate"]}" stroke-dasharray="5 4"/>')
    p.append(f'<rect x="{K.fmt(a0)}" y="{K.fmt(b0)}" width="{K.fmt(a1 - a0)}" height="{K.fmt(b1 - b0)}" fill="{C["white"]}"/>')
    p.append(stacked('primary', sx0, sy0, sw))
    return sheet(W, H, ''.join(p), f'{NAME} clear space')


VERDICT = [(17.5, 20, 13, 60, 0), (30.5, 43.5, 28.5, 13, 0)], (66, 40, 20, 20, 1.5)
KERNELS = [(43, 9, 14, 14, 1.5), (72.4, 26, 14, 14, 1.5), (72.4, 60, 14, 14, 1.5), (43, 77, 14, 14, 1.5),
           (13.6, 60, 14, 14, 1.5), (13.6, 26, 14, 14, 1.5)], (38, 38, 24, 24, 1.5)


def alt_mark(kind: str, k: float, ox: float, oy: float, bars: str, block: str) -> str:
    if kind == 'inference':
        return K.symbol(bars, block, k, ox, oy)
    rects, blk = VERDICT if kind == 'verdict' else KERNELS
    extra = ''
    if kind == 'kernels':
        pts = ' '.join(f'{K.fmt(ox + k * x)},{K.fmt(oy + k * y)}' for x, y in [(50, 16), (79.4, 33), (79.4, 67), (50, 84), (20.6, 67), (20.6, 33)])
        extra = f'<polygon points="{pts}" fill="none" stroke="{bars}" stroke-opacity="0.35" stroke-width="{K.fmt(3 * k)}"/>'
    d = ''.join(K.rrect(*K.place(r, k, ox, oy)) for r in rects)
    return extra + f'<path fill="{bars}" d="{d}"/><path fill="{block}" d="{K.rrect(*K.place(blk, k, ox, oy))}"/>'


def alternates() -> str:
    W, H = 1600, 700
    p = [f'<rect width="{W}" height="{H}" fill="{C["void"]}"/>']
    p.append(T('Three directions, one accepted', 'serif', 48, 64, 92, C['frost']))
    p.append(T('Shown to the owner on 2026-10-31. Proposal 02 was accepted; 01 and 03 are set aside and recorded here.', 'inter-400', 17, 64, 128, C['mist']))
    items = [
        ('verdict', '01 the verdict', 'Set aside', 'The turnstile, the sign for "is provable", followed by the end-of-proof block. Read together: proved.'),
        ('inference', '02 the inference', 'Accepted', 'An inference rule: two premises above the line, the conclusion below. The conclusion is the block, proved. It also reads as a fraction.'),
        ('kernels', '03 six kernels', 'Set aside', 'Six independent kernels around one proof. The most detailed of the three; at 16 px the ring becomes a texture around the block.'),
    ]
    for i, (kind, title, status, body) in enumerate(items):
        x = 64 + i * (456 + 52)
        accepted = kind == 'inference'
        p.append(card(x, 168, 456, 468, C['graphite'], C['forge'] if accepted else C['steel']))
        p.append(alt_mark(kind, 2.4, x + 228 - 120, 196, C['frost'], C['forge']))
        p.append(T(title, 'grotesk-600', 24, x + 36, 500, C['frost'], -0.01))
        p.append(T(status, 'inter-600', 15, x + 420, 500, C['forge'] if accepted else C['mist'], anchor='end'))
        para, _ = K.paragraph(body, 'inter-400', 15, x + 36, 540, 384, C['mist'], 24)
        p.append(para)
    return sheet(W, H, ''.join(p), f'{NAME} directions, accepted and set aside')


def og_image() -> str:
    """Social card, 1200 x 630: Void ground, the reversed lockup and the line."""
    W, H = 1200, 630
    p = [f'<rect width="{W}" height="{H}" fill="{C["void"]}"/>']
    dots = ''.join(f'M{x} {y}h0' for x in range(14, W, 28) for y in range(14, H, 28))
    p.append(f'<path d="{dots}" stroke="{C["steel"]}" stroke-width="2" stroke-linecap="round"/>')
    k = 5.0
    p.append(K.symbol(C['steel'], C['steel'], k, 1130 - 92 * k, 330 - 52 * k))
    w, h = horizontal_size(500)
    p.append(horizontal('reversed', 80 - 8 * 500 / GEO['horizontal']['width'], 110, w))
    p.append(T('Muse writes the fix.', 'serif', 78, 84, 360, C['frost']))
    p.append(T('Lean proves it.', 'serif', 78, 84, 446, C['frost']))
    p.append(T('Six independent kernels check the proof, and a Passport lets', 'inter-400', 22, 86, 512, C['mist']))
    p.append(T('anyone re-run the verdict.', 'inter-400', 22, 86, 544, C['mist']))
    return sheet(W, H, ''.join(p), f'{NAME} social card')


def favicon_ladder(out: Path) -> None:
    """Favicons at true size and magnified, on a light and a dark browser chrome."""
    W, H = 1600, 820
    rows = [(C['paper'], C['ink'], C['slate'], 'On a light tab bar'), (C['graphite'], C['frost'], C['mist'], 'On a dark tab bar')]
    p = [f'<rect width="{W}" height="{H}" fill="{C["white"]}"/>']
    p.append(T('Favicons at true size and magnified', 'serif', 44, 64, 84, C['ink']))
    p.append(T('PNG favicons up to 48 px use the small cut, fitted to whole pixels. Magnified views are nearest neighbour.', 'inter-400', 16, 64, 118, C['slate']))
    sizes = [16, 24, 32, 48, 64]
    places = []
    for r, (bg, fg, sub, label) in enumerate(rows):
        y = 150 + r * 320
        p.append(card(64, y, 1472, 300, bg, C['hairline'] if r == 0 else C['steel']))
        p.append(T(label, 'inter-600', 16, 96, y + 44, fg))
        x = 96
        for s in sizes:
            places.append(('1x', s, x, y + 160 - s, 1))
            p.append(T(f'{s} px', 'mono-400', 12, x + s / 2, y + 200, sub, anchor='middle'))
            x += max(s, 40) + 40
        for s, scale, mx in [(16, 12, 640), (32, 6, 900), (48, 4, 1160)]:
            places.append(('mag', s, mx, y + 64, scale))
            p.append(T(f'{s} px at {scale}x', 'mono-400', 12, mx + 96, y + 282, sub, anchor='middle'))
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp) / 'base.png'
        render(sheet(W, H, ''.join(p), 'Favicon ladder'), base, W)
        im = Image.open(base).convert('RGBA')
        for kind, s, x, y, scale in places:
            fav = Image.open(KIT / '04-web' / f'favicon-{s}x{s}.png').convert('RGBA')
            if scale != 1:
                fav = fav.resize((s * scale, s * scale), Image.NEAREST)
            im.alpha_composite(fav, (int(x), int(y)))
        im.convert('RGB').save(out, optimize=True)


def accepted_direction() -> str:
    g = GEO['horizontal']
    st = GEO['stacked']
    f = K.fmt
    m, wd = g['markInk'], g['wordInk']
    return '\n'.join([
        'ProofForge accepted direction',
        '',
        'Accepted on 2026-10-31 by the owner: proposal 02 "the inference". Proposal canvas (private to the owner): id 1PcEyQ3HBmFVBeJcA82scW, also recorded in delivery.json beside this kit.',
        '',
        'Meaning',
        'An inference rule as logicians write it: premises above the line, the conclusion below. The conclusion is the block, the end-of-proof mark: proved. The mark also reads as a fraction, the arithmetic that financial code gets wrong.',
        '',
        'Symbol geometry (100 unit grid; rect x, y, width, height, corner radius)',
        'Premise left: 14, 22, 30, 12, 1.5',
        'Premise right: 56, 22, 30, 12, 1.5',
        'Inference line: 8, 43, 84, 7, 0',
        'Conclusion block: 39, 60, 22, 22, 1.5',
        'Ink box: x 8 to 92, y 22 to 82 (84 by 60).',
        'Small cut for favicons and icons at 48 px and below: the inference line thickens to 10 units (8, 42, 84, 10), leaving gaps of 8 units above and below; PNG sizes are fitted to whole pixels. Legible at 16 px, checked on light and dark tab bars (07-reference/favicon-ladder.png).',
        '',
        'Colour in the mark',
        'Primary on light: Ink #0B0F15 bars and line, Forge deep #D45F00 block. Reversed on Void #05070B: #F2F5F8 bars and line, Forge #FF9A3C block. Mono ink and mono white: everything one colour. Verified #3DDC97 and Refuted #FF5D5D are never used in the mark.',
        '',
        'Wordmark',
        'Space Grotesk 700, lowercase "proofforge", tracking -0.045em, kerning on, no ligatures, outlined by 08-source/build-kit.py. The outlines match a browser rendering of the same setting.',
        f'Ink box at font size 100, y down from the baseline: x {f(wd[0] - g["wordOriginX"])} to {f(wd[2] - g["wordOriginX"])}, y {f(wd[1])} (top of the f) to {f(wd[3])} (bottom of the p and g). Ink centre: {f(g["wordCentreY"])}, that is 0.25 em above the baseline.',
        '',
        'Alignment rule for the horizontal lockup',
        'The mark is 0.78 of the wordmark font size high. Its vertical centre is level with the wordmark ink centre (top of the f to the bottom of the p and g). The gap from mark ink to wordmark ink is 0.33 em. Positions are computed from the outlined glyph bounds, not set by eye.',
        f'At font size 100: mark ink x {f(m[0])} to {f(m[2])}, y {f(m[1])} to {f(m[3])}, centre {f(g["markCentreY"])}; wordmark ink x {f(wd[0])} to {f(wd[2])}, centre {f(g["wordCentreY"])}; artboard {f(g["width"])} by {f(g["height"])} with a margin of 8.',
        'validate-kit.py renders every horizontal lockup and checks that the two ink centres differ by at most 0.5% of the lockup height.',
        '',
        'Stacked lockup',
        f'The mark is 1.25 em high and centred above the wordmark ink, 0.36 em above the top of the f. Artboard {f(st["width"])} by {f(st["height"])}.',
        '',
        'Alternates shown and set aside',
        '01 "the verdict": the turnstile (is provable) followed by the end-of-proof block. Geometry: rects 17.5, 20, 13, 60 and 30.5, 43.5, 28.5, 13; block 66, 40, 20, 20, r 1.5.',
        '03 "six kernels": six small blocks on a hexagon ring around a central block, one per checking kernel. Geometry: blocks of 14 at the hexagon points around 50, 50; centre block 38, 38, 24, 24, r 1.5. The most detailed of the three; at 16 px the ring becomes a texture.',
        'Both are drawn in 07-reference/alternates-set-aside.png.',
        '',
    ])


def font_faces(prefix: str) -> str:
    faces = [('Space Grotesk', 'SpaceGrotesk[wght].ttf', '300 700', 'normal'), ('Inter', 'Inter[opsz,wght].ttf', '100 900', 'normal'),
             ('JetBrains Mono', 'JetBrainsMono[wght].ttf', '100 800', 'normal'),
             ('Instrument Serif', 'InstrumentSerif-Regular.ttf', '400', 'normal'), ('Instrument Serif', 'InstrumentSerif-Italic.ttf', '400', 'italic')]
    return ''.join(f"@font-face{{font-family:'{f}';src:url('{prefix}{file}') format('truetype');font-weight:{w};font-style:{s};font-display:block}}"
                   for f, file, w, s in faces)


def gallery() -> str:
    cards = []
    for variant, dark in [('primary', False), ('reversed', True), ('mono-ink', False), ('mono-white', True)]:
        for kind in ['horizontal', 'stacked', 'icon', 'wordmark']:
            path = f'01-vector/{variant}/{BRAND}-{kind}-{variant}.svg'
            cards.append(f'<figure class="card{" dark" if dark else ""}"><img src="{path}" alt="ProofForge {kind}, {variant}">'
                         f'<figcaption><code>{path}</code></figcaption></figure>')
    css = (font_faces('08-source/fonts/') +
           f':root{{--void:{C["void"]};--graphite:{C["graphite"]};--steel:{C["steel"]};--mist:{C["mist"]};--frost:{C["frost"]};'
           f'--forge:{C["forge"]};--paper:{C["paper"]};--ink:{C["ink"]};--slate:{C["slate"]};--hairline:{C["hairline"]};color-scheme:dark}}'
           '*{box-sizing:border-box}body{margin:0;background:var(--void);color:var(--mist);font:16px/1.6 Inter,system-ui,sans-serif}'
           'main{max-width:1180px;margin:0 auto;padding:48px 16px 72px}'
           '.brand{display:block;width:min(100%,260px);height:auto;margin:0 0 36px}'
           "h1{font-family:'Instrument Serif',Georgia,serif;font-weight:400;font-size:clamp(40px,7vw,64px);line-height:1.05;color:var(--frost);margin:0 0 16px;letter-spacing:-.01em}"
           "h2{font-family:'Space Grotesk',Inter,sans-serif;font-weight:600;font-size:26px;letter-spacing:-.02em;color:var(--frost);margin:64px 0 8px}"
           'p{max-width:760px;margin:0 0 16px}a{color:var(--forge);text-underline-offset:3px}'
           'nav{display:flex;flex-wrap:wrap;gap:8px 24px;margin:24px 0 40px}'
           '.sheet{display:block;width:100%;height:auto;border-radius:16px;border:1px solid var(--steel)}'
           '.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,250px),1fr));gap:16px;margin-top:24px}'
           '.card{margin:0;background:var(--paper);border-radius:16px;padding:28px 24px 18px;min-width:0;display:flex;flex-direction:column;gap:16px}'
           '.card.dark{background:var(--graphite);border:1px solid var(--steel)}'
           '.card img{width:100%;height:110px;object-fit:contain}'
           '.card figcaption{font-size:12px;line-height:1.5;color:var(--slate)}.card.dark figcaption{color:var(--mist)}'
           "code{font-family:'JetBrains Mono',ui-monospace,monospace;overflow-wrap:anywhere}"
           '.pair{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr));gap:16px;margin-top:24px}'
           '.pair img,.pair video{display:block;width:100%;height:auto;border-radius:16px;border:1px solid var(--steel);background:var(--graphite)}'
           '.icons{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,150px),1fr));gap:16px;margin:24px 0}'
           '.icons figure{margin:0;background:var(--graphite);border:1px solid var(--steel);border-radius:16px;padding:24px;display:flex;flex-direction:column;align-items:center;gap:12px}'
           '.icons img{width:min(100%,128px);height:auto}.icons img.round{border-radius:50%}.icons figcaption{font-size:13px}'
           '.note{font-size:14px;color:var(--mist)}footer{margin-top:72px;font-size:14px}')
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>ProofForge logo kit</title><link rel="icon" href="04-web/favicon.svg" type="image/svg+xml">'
            f'<style>{css}</style></head><body><main>'
            '<img class="brand" src="01-vector/reversed/proofforge-horizontal-reversed.svg" alt="ProofForge">'
            '<h1>The ProofForge identity kit</h1>'
            '<p>The inference: two premises above the line, the conclusion below, and the conclusion is the block that ends a proof. '
            'Production vector masters, transparent exports, favicons, app icons, tokens and the splash animation. Accepted on 2026-10-31.</p>'
            '<nav><a href="ProofForge-Logo-Guide.pdf">Logo guide PDF</a><a href="README.txt">Asset guide</a>'
            '<a href="06-brand-tokens/proofforge-tokens.json">Tokens</a><a href="09-motion/proofforge-splash.html">Splash</a>'
            '<a href="manifest-sha256.json">File manifest</a></nav>'
            '<img class="sheet" src="ProofForge-Kit-Overview.png" alt="ProofForge identity overview: lockups, symbol anatomy and palette">'
            '<h2>Construction and alignment</h2>'
            '<p>The mark is 0.78 of the font size high and its centre sits level with the wordmark ink centre, 0.25 em above the baseline. '
            'The validator renders every horizontal lockup and checks this to 0.5% of the lockup height.</p>'
            '<img class="sheet" src="07-reference/construction.png" alt="Grid geometry and the lockup alignment rule">'
            '<h2>Masters</h2><p>Primary and mono ink on light grounds, reversed and mono white on dark grounds. Every master is outlined vector.</p>'
            f'<div class="grid">{"".join(cards)}</div>'
            '<h2>Favicons and icons</h2><p>Up to 48 px the inference line thickens to 10 units and every edge lands on a whole pixel.</p>'
            '<img class="sheet" src="07-reference/favicon-ladder.png" alt="Favicons at true size and magnified on light and dark tab bars">'
            '<div class="icons"><figure><img src="05-app-icons/dark/proofforge-app-dark-rounded-preview-512.png" alt="App icon, dark"><figcaption>App icon, dark</figcaption></figure>'
            '<figure><img src="05-app-icons/light/proofforge-app-light-rounded-preview-512.png" alt="App icon, light"><figcaption>App icon, light</figcaption></figure>'
            '<figure><img src="04-web/icon-512.png" alt="Installable icon"><figcaption>Installable icon</figcaption></figure>'
            '<figure><img class="round" src="04-web/maskable-icon-512.png" alt="Maskable icon in a circular mask"><figcaption>Maskable, circle mask</figcaption></figure></div>'
            '<div class="pair"><img src="04-web/og-image.png" alt="Social card: Muse writes the fix. Lean proves it."></div>'
            '<h2>Splash</h2><p>Premises, then the inference line, then the conclusion lands; the mark slides left as the wordmark arrives. '
            'About 4.5 seconds, with reduced motion showing the final lockup at once.</p>'
            '<div class="pair"><a href="09-motion/proofforge-splash-1920x1080.mp4"><img src="09-motion/proofforge-splash-frames.png" '
            'alt="Key frames of the splash, from the premises to the final lockup"></a></div>'
            '<p class="note"><a href="09-motion/proofforge-splash.html">Open the HTML splash</a>, '
            '<a href="09-motion/proofforge-splash-1920x1080.mp4">1920 x 1080 MP4</a>, '
            '<a href="09-motion/proofforge-splash-1080x1080.mp4">1080 x 1080 MP4</a>, '
            '<a href="09-motion/proofforge-splash-960x540.gif">GIF</a>.</p>'
            '<h2>Directions</h2>'
            '<img class="sheet" src="07-reference/alternates-set-aside.png" alt="Three proposed directions; 02 the inference accepted">'
            '<footer><p>Fonts under the SIL Open Font License, in 08-source/fonts. Rebuild with the scripts in 08-source; '
            'verify a copy against manifest-sha256.json.</p></footer>'
            '</main></body></html>\n')


def guide_html() -> str:
    """The logo guide, A4, three pages, printed by headless Chrome."""
    kit = KIT.as_uri() + '/'
    g = GEO['horizontal']
    sw = ''.join(f'<div class="sw"><span style="background:{C[k]}"></span><b>{n}</b><code>{C[k]}</code><i>{use}</i></div>'
                 for (n, k), use in zip(SWATCHES, [
                     'Page ground in dark', 'Cards and panels on dark', 'Card edges on dark', 'Body text on dark',
                     'The block on dark; one accent per view', 'The block on light; large accents on light', 'Proof graphs and Lean code on dark',
                     'Page ground in light', 'The verified verdict only', 'The refuted verdict only', 'Text and mark on light', 'Body text on light']))
    css = (font_faces(kit + '08-source/fonts/') +
           '@page{size:A4;margin:0}*{box-sizing:border-box}html,body{margin:0}'
           f'body{{font:10pt/1.5 Inter,sans-serif;color:{C["slate"]};-webkit-print-color-adjust:exact;print-color-adjust:exact}}'
           '.page{width:210mm;height:297mm;padding:16mm 18mm;position:relative;overflow:hidden;break-after:page;display:flex;flex-direction:column;gap:5mm}'
           '.page:last-child{break-after:auto}'
           f'.dark{{background:{C["void"]};color:{C["mist"]}}}'
           f"h1{{font-family:'Instrument Serif',serif;font-weight:400;font-size:40pt;line-height:1.02;margin:0;text-wrap:balance;color:{C['ink']}}}"
           f'.dark h1{{color:{C["frost"]}}}'
           f"h2{{font-family:'Space Grotesk',sans-serif;font-weight:600;font-size:14pt;letter-spacing:-.01em;margin:0 0 1.5mm;color:{C['ink']}}}"
           f'.dark h2{{color:{C["frost"]}}}'
           'p{margin:0 0 2mm}'
           f"code,.mono{{font-family:'JetBrains Mono',monospace;font-size:8.5pt}}"
           '.cols{display:grid;grid-template-columns:1fr 1fr;gap:6mm}'
           f'.panel{{border-radius:4mm;padding:6mm;background:{C["white"]};border:0.3mm solid {C["hairline"]}}}'
           f'.panel.d{{background:{C["graphite"]};border-color:{C["steel"]}}}'
           '.panel img{display:block;width:100%;height:auto}'
           'table{border-collapse:collapse;width:100%}td{padding:1mm 0;vertical-align:top}td:first-child{width:36mm;font-weight:600}'
           f'.dark td:first-child{{color:{C["frost"]}}}'
           f'td:first-child{{color:{C["ink"]}}}'
           '.sws{display:grid;grid-template-columns:repeat(4,1fr);gap:4mm}'
           f'.sw span{{display:block;height:13mm;border-radius:2.5mm;border:0.3mm solid {C["hairline"]};margin-bottom:1.5mm}}'
           f'.sw b{{display:block;color:{C["ink"]};font-weight:600}}.sw code{{display:block}}.sw i{{display:block;font-style:normal;font-size:8pt;line-height:1.35}}'
           f'.foot{{position:absolute;left:18mm;right:18mm;bottom:9mm;font-size:8pt;display:flex;justify-content:space-between}}'
           f"ul{{margin:0;padding-left:4.5mm}}li{{margin:0 0 1mm}}"
           '.vars{display:grid;grid-template-columns:repeat(4,1fr);gap:3mm}.vars div{border-radius:3mm;padding:5mm 4mm}.vars img{display:block;width:100%}')
    f = K.fmt
    m, wd = g['markInk'], g['wordInk']
    pages = []
    pages.append(f'''<section class="page dark">
<img src="{kit}01-vector/reversed/proofforge-horizontal-reversed.svg" style="width:92mm;margin:2mm 0 8mm" alt="ProofForge">
<h1>A rule of inference, and the proof it ends.</h1>
<p style="font-size:11.5pt;max-width:150mm;color:{C['mist']}">ProofForge logo guide, version 1.0, accepted on 2026-10-31. The symbol is an inference rule as logicians write it: two premises above the line and the conclusion below. The conclusion is the block, the end-of-proof mark: proved. It also reads as a fraction, the arithmetic that financial code gets wrong.</p>
<div class="panel d" style="padding:6mm 9mm"><img src="{kit}07-reference/anatomy.svg" style="width:125mm" alt="Symbol anatomy"></div>
<div class="cols">
<div><h2>Construction</h2><table>
<tr><td>Premises</td><td><code>14, 22, 30 x 12</code> and <code>56, 22, 30 x 12</code>, radius 1.5</td></tr>
<tr><td>Inference line</td><td><code>8, 43, 84 x 7</code></td></tr>
<tr><td>Conclusion</td><td><code>39, 60, 22 x 22</code>, radius 1.5</td></tr>
<tr><td>Ink box</td><td>x 8 to 92, y 22 to 82 on a 100 unit grid</td></tr>
<tr><td>Small cut</td><td>48 px and below: line <code>8, 42, 84 x 10</code>, gaps of 8, edges on whole pixels</td></tr></table></div>
<div><h2>Colour in the mark</h2>
<p>Primary on light: Ink bars and line, Forge deep block. Reversed on Void: <code>#F2F5F8</code> bars and line, Forge block. Mono ink and mono white: one colour throughout.</p>
<p>The block is the one accent in any view. Verified and Refuted belong to verdicts and never enter the mark.</p></div>
</div>
<div class="vars">
<div style="background:{C['paper']}"><img src="{kit}01-vector/primary/proofforge-horizontal-primary.svg" alt="Primary"></div>
<div style="background:{C['graphite']};border:0.3mm solid {C['steel']}"><img src="{kit}01-vector/reversed/proofforge-horizontal-reversed.svg" alt="Reversed"></div>
<div style="background:{C['white']}"><img src="{kit}01-vector/mono-ink/proofforge-horizontal-mono-ink.svg" alt="Mono ink"></div>
<div style="background:{C['slate']}"><img src="{kit}01-vector/mono-white/proofforge-horizontal-mono-white.svg" alt="Mono white"></div>
</div>
<p style="font-size:8.5pt">Primary on Paper, reversed on Void and Graphite, mono ink for one-colour print, mono white on photographs and mid-tone grounds.</p>
<div class="foot"><span>ProofForge logo guide 1.0</span><span>1 of 3</span></div>
</section>''')
    pages.append(f'''<section class="page">
<h1>Lockups</h1>
<div class="panel" style="padding:2mm"><img src="{kit}07-reference/alignment-rule.svg" alt="The alignment rule"></div>
<div class="cols">
<div><h2>The alignment rule</h2>
<p>In the horizontal lockup the mark is 0.78 of the wordmark font size high, and its vertical centre is level with the wordmark ink centre: the midpoint between the top of the f and the bottom of the p and g, 0.25 em above the baseline. The gap from mark to wordmark is 0.33 em.</p>
<p>At font size 100 the mark runs from <code>{f(m[1])}</code> to <code>{f(m[3])}</code> and the wordmark ink from <code>{f(wd[1])}</code> to <code>{f(wd[3])}</code>; both centres are <code>{f(g['wordCentreY'])}</code>. Positions come from the outlined glyph bounds, and the validator checks every rendered lockup.</p></div>
<div><h2>Choosing a lockup</h2>
<ul><li>Horizontal is the default, for headers, documents and app bars.</li>
<li>Stacked suits square placements: the mark, 1.25 em high, centred above the wordmark.</li>
<li>The symbol alone is for avatars, favicons and app icons.</li>
<li>The wordmark alone is for places that already show the symbol nearby.</li></ul>
<h2 style="margin-top:4mm">Space and size</h2>
<p>Clear space: half the symbol height on every side. Minimum sizes: symbol 16 px on screen and 5 mm in print; horizontal lockup 120 px wide; wordmark alone 90 px wide.</p></div>
</div>
<div class="panel" style="padding:2mm"><img src="{kit}07-reference/clear-space.svg" alt="Clear space around the horizontal and stacked lockups"></div>
<div class="foot"><span>ProofForge logo guide 1.0</span><span>2 of 3</span></div>
</section>''')
    pages.append(f'''<section class="page">
<h1>Colour and type</h1>
<div class="sws">{sw}</div>
<p style="font-size:9pt">Supporting values: <code>#F2F5F8</code> for the mark and headings on dark, Hairline <code>#E1E5EB</code> for card edges on light, white for cards on light. Contrast: Mist on Void 9.6:1, Slate on Paper 7.2:1, Forge on Void 9.5:1. Forge deep on white is 3.9:1, so use it for the block and large type only, never small text.</p>
<div class="cols">
<div><h2>Type</h2>
<p style="font-family:'Instrument Serif',serif;font-size:24pt;line-height:1.1;color:{C['ink']};margin:0">Every fix carries its <em>proof</em>.</p><p>Instrument Serif: page headlines only.</p>
<p style="font-family:'Space Grotesk',sans-serif;font-weight:600;font-size:18pt;letter-spacing:-.02em;color:{C['ink']};margin:0">0 of 247, $3.06</p><p>Space Grotesk: the wordmark, figures and section titles.</p>
<p style="font-size:11pt;color:{C['ink']};margin:0">Six independent kernels check the proof.</p><p>Inter: interface and body, 400, 500 and 600.</p>
<p class="mono" style="font-size:10pt;color:{C['ink']};margin:0">theorem req_batch_keeps_value : ...</p><p>JetBrains Mono: Lean, hashes and Passport readings; Ion on dark grounds.</p>
<p>Labels are sentence case. No uppercase eyebrow labels above headings.</p></div>
<div><h2>Do not</h2>
<ul><li>Change the grid, the gaps or the order of the parts.</li>
<li>Set the wordmark in a live font, or restyle it.</li>
<li>Align the mark to the baseline or the x-height; use the ink centre rule.</li>
<li>Use Verified, Refuted or Ion in the mark.</li>
<li>Add a second accent next to the Forge block.</li>
<li>Rotate, outline, add gradients, glows or shadows to the static mark.</li>
<li>Crowd the lockup inside its clear space, or set the primary lockup on photographs or busy grounds.</li></ul>
<h2 style="margin-top:4mm">Files</h2>
<p>01-vector SVG masters, 02-png-transparent, 03-vector-pdf, 04-web favicons and social card, 05-app-icons, 06-brand-tokens, 07-reference, 08-source build scripts and fonts, 09-motion splash.</p></div>
</div>
<div class="foot"><span>Fonts under the SIL Open Font License; rebuild with 08-source</span><span>3 of 3</span></div>
</section>''')
    return f'<!doctype html><html lang="en"><head><meta charset="utf-8"><title>ProofForge logo guide</title><style>{css}</style></head><body>{"".join(pages)}</body></html>\n'


def anatomy_svg() -> str:
    W, H = 640, 220
    body = anatomy(20, 40, 140, 300, C['frost'], C['forge'], C['mist'], C['ion'], 18)
    return sheet(W, H, body, f'{NAME} symbol anatomy')


def build() -> None:
    ref = KIT / '07-reference'
    (KIT / 'ProofForge-Kit-Overview.svg').write_text(overview())
    render(overview(), KIT / 'ProofForge-Kit-Overview.png', 1600)
    (ref / 'construction.svg').write_text(construction())
    render(construction(), ref / 'construction.png', 1600)
    (ref / 'alternates-set-aside.svg').write_text(alternates())
    render(alternates(), ref / 'alternates-set-aside.png', 1600)
    (ref / 'anatomy.svg').write_text(anatomy_svg())
    (ref / 'alignment-rule.svg').write_text(alignment_sheet())
    render(alignment_sheet(), ref / 'alignment-rule.png', 1600)
    (ref / 'clear-space.svg').write_text(clear_space_sheet())
    render(clear_space_sheet(), ref / 'clear-space.png', 1600)
    favicon_ladder(ref / 'favicon-ladder.png')
    (ref / 'accepted-direction.txt').write_text(accepted_direction())
    render(og_image(), KIT / '04-web' / 'og-image.png', 1200)
    (KIT / '04-web' / 'og-image.svg').write_text(og_image())
    (KIT / 'index.html').write_text(gallery())
    with tempfile.TemporaryDirectory() as tmp:
        g = Path(tmp) / 'guide.html'
        g.write_text(guide_html())
        browser([{'type': 'pdf', 'url': g.as_uri(), 'out': str(KIT / 'ProofForge-Logo-Guide.pdf')}])
    K.manifest()


if __name__ == '__main__':
    build()
    print('docs built')
