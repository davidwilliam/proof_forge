ProofForge logo kit, version 1.0, 2026-10-31

The accepted "inference" identity, prepared as production vector artwork. The symbol is an inference rule as logicians write it: two premises above the line, the conclusion below. The conclusion is the block, the end-of-proof mark: proved. It also reads as a fraction, the arithmetic that financial code gets wrong. The symbol sits on a 100 unit grid with an ink box of 84 by 60 units. The wordmark is Space Grotesk at weight 700, lowercase, tracked at -0.045em, kerned and frozen into outlines. No font or raster dependency remains in the masters.

Choose an asset
Primary: Ink bars and line, Forge deep block and Ink lettering, for light grounds. Reversed: #F2F5F8 bars, line and lettering with a Forge block, for Void and Graphite grounds. Mono ink and mono white: everything in one colour, for one-colour print, embossing, photographs and mid-tone grounds. Horizontal is the default lockup; stacked suits square placements; the symbol alone is for avatars, favicons and app icons; the wordmark alone is for places that already show the symbol nearby.

The alignment rule
In the horizontal lockup the mark is 0.78 of the wordmark font size high, and its vertical centre is level with the wordmark ink centre: the midpoint between the top of the f and the bottom of the p and g, 0.25 em above the baseline. The gap from mark ink to wordmark ink is 0.33 em. All positions are computed from the outlined glyph bounds. The stacked lockup centres the mark, 1.25 em high, above the wordmark ink, 0.36 em above the top of the f. 07-reference/accepted-direction.txt records the exact coordinates, and validate-kit.py, beside this kit, renders every horizontal lockup and checks the two ink centres to 0.5% of the lockup height.

Formats
01-vector: SVG masters; every shape is a filled path and the wordmark is outlined. 02-png-transparent: sRGB PNG exports, up to 4096 px wide for lockups and 2048 px for the symbol. 03-vector-pdf: vector RGB PDF counterparts. 04-web: favicon SVG, ICO and PNG sizes, installable and maskable icons, a 1200 by 630 social card (PNG and outlined SVG), an example web manifest and head snippet. 05-app-icons: dark (Void) and light (Paper) full-square artwork with PNG sizes, rounded previews, ICO and ICNS. 06-brand-tokens: colours, light and dark role sets, type, symbol geometry and lockup ratios, in JSON and CSS. 07-reference: the acceptance record, the construction and alignment sheets, clear space, the favicon ladder, the reference symbol and small cut, and the two alternates set aside. 08-source: the build scripts and the fonts they need. 09-motion: the splash animation as standalone HTML with MP4 and GIF renders, posters and key frames.

Colour
Void #05070B (dark ground). Graphite #0E131B (cards and panels on dark). Steel #1C2532 (card edges on dark). Mist #A9B4C2 (body text on dark, 9.6:1 on Void). Forge #FF9A3C (the block on dark; one accent per view). Forge deep #D45F00 (the block on light; 3.9:1 on white, so large type and graphics only, never small text). Ion #5BE4F0 (proof graphs and Lean code on dark). Paper #F6F7F9 (light ground). Verified #3DDC97 and Refuted #FF5D5D (verdicts only, never in the mark; on light grounds use them as fills behind Ink text). Ink #0B0F15 (text and mark on light). Slate #4A5462 (body text on light, 7.2:1 on Paper). Supporting values: #F2F5F8 for the mark and headings on dark, Hairline #E1E5EB for card edges on light, white for cards on light. Use exact sRGB values; PNGs carry sRGB. PDFs are RGB; no press CMYK or Pantone match is claimed.

Typography
Instrument Serif for page headlines only. Space Grotesk for the wordmark, figures and section titles (500, 600, 700). Inter for interface and body (400, 500, 600). JetBrains Mono for Lean, hashes and Passport readings, in Ion on dark grounds. All four are under the SIL Open Font License and ship in 08-source/fonts. Labels are sentence case; ProofForge never uses uppercase eyebrow labels above headings.

Space and size
Keep clear space of half the symbol height on every side of any lockup. Minimum sizes: symbol 16 px on screen and 5 mm in print; horizontal lockup 120 px wide; wordmark alone 90 px wide. Do not change the grid, the gaps or the order of the parts, align the mark to the baseline or the x-height, set the wordmark in a live font, put Verified, Refuted or Ion into the mark, add a second accent beside the Forge block, or add gradients, glows or shadows to the static mark.

Favicons and installable icons
The favicon is the reversed symbol on a Void tile with rounded corners, so it reads on light and dark tab bars alike. At 48 px and below it uses the small cut: the inference line thickens to 10 units, leaving gaps of 8 units, and every edge is fitted to a whole pixel, so at 16 px the premises, the line and the block stay separate with one clear pixel between them. The SVG favicon carries the 16 px fit, which also lands on whole pixels at 32 px. The ICO carries 16 to 64 px. Installable icons use a full Void square with the reversed symbol; the maskable variants keep the symbol inside the safe circle. Install every size together and version the URLs when they change.

Application icons
Dark (Void) and light (Paper) full-square artwork is provided; operating systems apply their own masks. ICO and ICNS frames at 48 px and below use the pixel-fitted small cut. Rounded previews show the expected result and are not shipping assets.

Motion
09-motion/proofforge-splash.html is a standalone page with inline SVG and CSS keyframes, no scripts and no fonts. On a Void ground the two premises drop in one after the other, labelled "premises"; the inference line draws from the centre outward, labelled "inference line"; the conclusion block lands with a short Forge glow, labelled "conclusion: proved"; the labels fade and the mark sits centred; then the mark slides left while the wordmark wipes in to the right at its final gap, ending on the centred horizontal lockup at about 4.5 s. With reduced motion requested, the page shows the final lockup at once. Renders: MP4 at 1920 by 1080 and 1080 by 1080 (30 fps, H.264), GIF at 960 by 540 and 540 by 540, final-frame posters and a key frame sheet.

Rebuild and verify
Run 08-source/build-kit.py (01 to 06 and the reference geometry), then build-docs.py (sheets, social card, guide, gallery), then build-motion.py (09-motion and manifest-sha256.json). They need Python with fontTools and Pillow, rsvg-convert, ImageMagick and macOS iconutil for ICNS; the docs and motion steps also need Node 22 or later, Chrome or chrome-headless-shell and ffmpeg. 08-source/browser.mjs drives headless Chrome; set CHROME to choose a browser. Sheet text is outlined from 08-source/fonts, so no installed font changes the output; fonts.conf points fontconfig at the same folder for other tools. Compare manifest-sha256.json to verify a copy of this kit.

Reference
Accepted by the owner on 2026-10-31: proposal 02 "the inference". Set aside: 01 "the verdict" (turnstile with end-of-proof block) and 03 "six kernels". See 07-reference.
